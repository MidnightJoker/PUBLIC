﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DlgDefectColor
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.btnSave = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtDP1 = New System.Windows.Forms.TextBox
        Me.DlgColor = New System.Windows.Forms.ColorDialog
        Me.txtDP2 = New System.Windows.Forms.TextBox
        Me.txtDP3 = New System.Windows.Forms.TextBox
        Me.txtDPx = New System.Windows.Forms.TextBox
        Me.txtDPn = New System.Windows.Forms.TextBox
        Me.txtBPn = New System.Windows.Forms.TextBox
        Me.txtBPx = New System.Windows.Forms.TextBox
        Me.txtBP3 = New System.Windows.Forms.TextBox
        Me.txtBP2 = New System.Windows.Forms.TextBox
        Me.txtBP1 = New System.Windows.Forms.TextBox
        Me.txtBPDPn = New System.Windows.Forms.TextBox
        Me.txtBPDPx = New System.Windows.Forms.TextBox
        Me.txtBPDP3 = New System.Windows.Forms.TextBox
        Me.txtBPDP2 = New System.Windows.Forms.TextBox
        Me.txtMark = New System.Windows.Forms.TextBox
        Me.txtHOL = New System.Windows.Forms.TextBox
        Me.txtVOL = New System.Windows.Forms.TextBox
        Me.txtHL = New System.Windows.Forms.TextBox
        Me.txtVL = New System.Windows.Forms.TextBox
        Me.txtXL = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnDefault = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtMURA = New System.Windows.Forms.TextBox
        Me.txtCP = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtSBP = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtOmitBP = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtBB = New System.Windows.Forms.TextBox
        Me.txtFG = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.txtGSDP = New System.Windows.Forms.TextBox
        Me.txtGSBP = New System.Windows.Forms.TextBox
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.btnSave, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.btnCancel, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(351, 174)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 26)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'btnSave
        '
        Me.btnSave.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnSave.Location = New System.Drawing.Point(3, 2)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(67, 22)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(76, 2)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(67, 22)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.Text = "Cancel"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.SystemColors.Control
        Me.Label20.Location = New System.Drawing.Point(19, 127)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(45, 12)
        Me.Label20.TabIndex = 76
        Me.Label20.Text = "DP-Near"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.SystemColors.Control
        Me.Label31.Location = New System.Drawing.Point(9, 104)
        Me.Label31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(56, 12)
        Me.Label31.TabIndex = 75
        Me.Label31.Text = "DP-Cluster"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.SystemColors.Control
        Me.Label25.Location = New System.Drawing.Point(15, 79)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(49, 12)
        Me.Label25.TabIndex = 74
        Me.Label25.Text = "3DP-ADJ"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.SystemColors.Control
        Me.Label15.Location = New System.Drawing.Point(22, 54)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(41, 12)
        Me.Label15.TabIndex = 73
        Me.Label15.Text = "DP-Pair"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(43, 33)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(19, 12)
        Me.Label3.TabIndex = 72
        Me.Label3.Text = "DP"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.SystemColors.Control
        Me.Label34.Location = New System.Drawing.Point(106, 127)
        Me.Label34.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(45, 12)
        Me.Label34.TabIndex = 81
        Me.Label34.Text = "BP-Near"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.SystemColors.Control
        Me.Label32.Location = New System.Drawing.Point(97, 104)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(56, 12)
        Me.Label32.TabIndex = 80
        Me.Label32.Text = "BP-Cluster"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.SystemColors.Control
        Me.Label26.Location = New System.Drawing.Point(103, 79)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(49, 12)
        Me.Label26.TabIndex = 79
        Me.Label26.Text = "3BP-ADJ"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.SystemColors.Control
        Me.Label16.Location = New System.Drawing.Point(110, 54)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(41, 12)
        Me.Label16.TabIndex = 78
        Me.Label16.Text = "BP-Pair"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(130, 33)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(19, 12)
        Me.Label2.TabIndex = 77
        Me.Label2.Text = "BP"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.BackColor = System.Drawing.SystemColors.Control
        Me.Label36.Location = New System.Drawing.Point(194, 105)
        Me.Label36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(59, 12)
        Me.Label36.TabIndex = 85
        Me.Label36.Text = "BPDP-Near"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.SystemColors.Control
        Me.Label28.Location = New System.Drawing.Point(184, 81)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(70, 12)
        Me.Label28.TabIndex = 84
        Me.Label28.Text = "BPDP-Cluster"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.SystemColors.Control
        Me.Label22.Location = New System.Drawing.Point(190, 57)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(63, 12)
        Me.Label22.TabIndex = 83
        Me.Label22.Text = "3BPDP-ADJ"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.SystemColors.Control
        Me.Label18.Location = New System.Drawing.Point(197, 32)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(55, 12)
        Me.Label18.TabIndex = 82
        Me.Label18.Text = "BPDP-Pair"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.BackColor = System.Drawing.SystemColors.Control
        Me.Label38.Location = New System.Drawing.Point(308, 11)
        Me.Label38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(42, 12)
        Me.Label38.TabIndex = 90
        Me.Label38.Text = "X-Short"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.Location = New System.Drawing.Point(309, 105)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(42, 12)
        Me.Label10.TabIndex = 89
        Me.Label10.Text = "H-Open"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Location = New System.Drawing.Point(309, 82)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(42, 12)
        Me.Label12.TabIndex = 88
        Me.Label12.Text = "V-Open"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.Location = New System.Drawing.Point(312, 56)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(38, 12)
        Me.Label9.TabIndex = 87
        Me.Label9.Text = "H-Line"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Location = New System.Drawing.Point(312, 32)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(38, 12)
        Me.Label4.TabIndex = 86
        Me.Label4.Text = "V-Line"
        '
        'txtDP1
        '
        Me.txtDP1.BackColor = System.Drawing.SystemColors.Window
        Me.txtDP1.Location = New System.Drawing.Point(66, 29)
        Me.txtDP1.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDP1.Name = "txtDP1"
        Me.txtDP1.ReadOnly = True
        Me.txtDP1.Size = New System.Drawing.Size(19, 22)
        Me.txtDP1.TabIndex = 91
        '
        'txtDP2
        '
        Me.txtDP2.BackColor = System.Drawing.SystemColors.Window
        Me.txtDP2.Location = New System.Drawing.Point(66, 52)
        Me.txtDP2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDP2.Name = "txtDP2"
        Me.txtDP2.ReadOnly = True
        Me.txtDP2.Size = New System.Drawing.Size(19, 22)
        Me.txtDP2.TabIndex = 92
        '
        'txtDP3
        '
        Me.txtDP3.BackColor = System.Drawing.SystemColors.Window
        Me.txtDP3.Location = New System.Drawing.Point(66, 76)
        Me.txtDP3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDP3.Name = "txtDP3"
        Me.txtDP3.ReadOnly = True
        Me.txtDP3.Size = New System.Drawing.Size(19, 22)
        Me.txtDP3.TabIndex = 93
        '
        'txtDPx
        '
        Me.txtDPx.BackColor = System.Drawing.SystemColors.Window
        Me.txtDPx.Location = New System.Drawing.Point(66, 100)
        Me.txtDPx.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDPx.Name = "txtDPx"
        Me.txtDPx.ReadOnly = True
        Me.txtDPx.Size = New System.Drawing.Size(19, 22)
        Me.txtDPx.TabIndex = 94
        '
        'txtDPn
        '
        Me.txtDPn.BackColor = System.Drawing.SystemColors.Window
        Me.txtDPn.Location = New System.Drawing.Point(66, 124)
        Me.txtDPn.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDPn.Name = "txtDPn"
        Me.txtDPn.ReadOnly = True
        Me.txtDPn.Size = New System.Drawing.Size(19, 22)
        Me.txtDPn.TabIndex = 95
        '
        'txtBPn
        '
        Me.txtBPn.BackColor = System.Drawing.SystemColors.Window
        Me.txtBPn.Location = New System.Drawing.Point(153, 124)
        Me.txtBPn.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBPn.Name = "txtBPn"
        Me.txtBPn.ReadOnly = True
        Me.txtBPn.Size = New System.Drawing.Size(19, 22)
        Me.txtBPn.TabIndex = 100
        '
        'txtBPx
        '
        Me.txtBPx.BackColor = System.Drawing.SystemColors.Window
        Me.txtBPx.Location = New System.Drawing.Point(153, 100)
        Me.txtBPx.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBPx.Name = "txtBPx"
        Me.txtBPx.ReadOnly = True
        Me.txtBPx.Size = New System.Drawing.Size(19, 22)
        Me.txtBPx.TabIndex = 99
        '
        'txtBP3
        '
        Me.txtBP3.BackColor = System.Drawing.SystemColors.Window
        Me.txtBP3.Location = New System.Drawing.Point(153, 76)
        Me.txtBP3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBP3.Name = "txtBP3"
        Me.txtBP3.ReadOnly = True
        Me.txtBP3.Size = New System.Drawing.Size(19, 22)
        Me.txtBP3.TabIndex = 98
        '
        'txtBP2
        '
        Me.txtBP2.BackColor = System.Drawing.SystemColors.Window
        Me.txtBP2.Location = New System.Drawing.Point(153, 51)
        Me.txtBP2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBP2.Name = "txtBP2"
        Me.txtBP2.ReadOnly = True
        Me.txtBP2.Size = New System.Drawing.Size(19, 22)
        Me.txtBP2.TabIndex = 97
        '
        'txtBP1
        '
        Me.txtBP1.BackColor = System.Drawing.SystemColors.Window
        Me.txtBP1.Location = New System.Drawing.Point(153, 28)
        Me.txtBP1.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBP1.Name = "txtBP1"
        Me.txtBP1.ReadOnly = True
        Me.txtBP1.Size = New System.Drawing.Size(19, 22)
        Me.txtBP1.TabIndex = 96
        '
        'txtBPDPn
        '
        Me.txtBPDPn.BackColor = System.Drawing.SystemColors.Window
        Me.txtBPDPn.Location = New System.Drawing.Point(254, 102)
        Me.txtBPDPn.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBPDPn.Name = "txtBPDPn"
        Me.txtBPDPn.ReadOnly = True
        Me.txtBPDPn.Size = New System.Drawing.Size(19, 22)
        Me.txtBPDPn.TabIndex = 105
        '
        'txtBPDPx
        '
        Me.txtBPDPx.BackColor = System.Drawing.SystemColors.Window
        Me.txtBPDPx.Location = New System.Drawing.Point(254, 78)
        Me.txtBPDPx.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBPDPx.Name = "txtBPDPx"
        Me.txtBPDPx.ReadOnly = True
        Me.txtBPDPx.Size = New System.Drawing.Size(19, 22)
        Me.txtBPDPx.TabIndex = 104
        '
        'txtBPDP3
        '
        Me.txtBPDP3.BackColor = System.Drawing.SystemColors.Window
        Me.txtBPDP3.Location = New System.Drawing.Point(254, 54)
        Me.txtBPDP3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBPDP3.Name = "txtBPDP3"
        Me.txtBPDP3.ReadOnly = True
        Me.txtBPDP3.Size = New System.Drawing.Size(19, 22)
        Me.txtBPDP3.TabIndex = 103
        '
        'txtBPDP2
        '
        Me.txtBPDP2.BackColor = System.Drawing.SystemColors.Window
        Me.txtBPDP2.Location = New System.Drawing.Point(254, 29)
        Me.txtBPDP2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBPDP2.Name = "txtBPDP2"
        Me.txtBPDP2.ReadOnly = True
        Me.txtBPDP2.Size = New System.Drawing.Size(19, 22)
        Me.txtBPDP2.TabIndex = 102
        '
        'txtMark
        '
        Me.txtMark.BackColor = System.Drawing.SystemColors.Window
        Me.txtMark.Location = New System.Drawing.Point(66, 174)
        Me.txtMark.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMark.Name = "txtMark"
        Me.txtMark.ReadOnly = True
        Me.txtMark.Size = New System.Drawing.Size(19, 22)
        Me.txtMark.TabIndex = 101
        '
        'txtHOL
        '
        Me.txtHOL.BackColor = System.Drawing.SystemColors.Window
        Me.txtHOL.Location = New System.Drawing.Point(352, 102)
        Me.txtHOL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtHOL.Name = "txtHOL"
        Me.txtHOL.ReadOnly = True
        Me.txtHOL.Size = New System.Drawing.Size(19, 22)
        Me.txtHOL.TabIndex = 110
        '
        'txtVOL
        '
        Me.txtVOL.BackColor = System.Drawing.SystemColors.Window
        Me.txtVOL.Location = New System.Drawing.Point(352, 78)
        Me.txtVOL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtVOL.Name = "txtVOL"
        Me.txtVOL.ReadOnly = True
        Me.txtVOL.Size = New System.Drawing.Size(19, 22)
        Me.txtVOL.TabIndex = 109
        '
        'txtHL
        '
        Me.txtHL.BackColor = System.Drawing.SystemColors.Window
        Me.txtHL.Location = New System.Drawing.Point(352, 54)
        Me.txtHL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtHL.Name = "txtHL"
        Me.txtHL.ReadOnly = True
        Me.txtHL.Size = New System.Drawing.Size(19, 22)
        Me.txtHL.TabIndex = 108
        '
        'txtVL
        '
        Me.txtVL.BackColor = System.Drawing.SystemColors.Window
        Me.txtVL.Location = New System.Drawing.Point(352, 29)
        Me.txtVL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtVL.Name = "txtVL"
        Me.txtVL.ReadOnly = True
        Me.txtVL.Size = New System.Drawing.Size(19, 22)
        Me.txtVL.TabIndex = 107
        '
        'txtXL
        '
        Me.txtXL.BackColor = System.Drawing.SystemColors.Window
        Me.txtXL.Location = New System.Drawing.Point(352, 6)
        Me.txtXL.Margin = New System.Windows.Forms.Padding(2)
        Me.txtXL.Name = "txtXL"
        Me.txtXL.ReadOnly = True
        Me.txtXL.Size = New System.Drawing.Size(19, 22)
        Me.txtXL.TabIndex = 106
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(10, 177)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 12)
        Me.Label1.TabIndex = 111
        Me.Label1.Text = "Mark-Line"
        '
        'btnDefault
        '
        Me.btnDefault.Location = New System.Drawing.Point(193, 176)
        Me.btnDefault.Margin = New System.Windows.Forms.Padding(2)
        Me.btnDefault.Name = "btnDefault"
        Me.btnDefault.Size = New System.Drawing.Size(67, 22)
        Me.btnDefault.TabIndex = 112
        Me.btnDefault.Text = "Default"
        Me.btnDefault.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Location = New System.Drawing.Point(213, 11)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(39, 12)
        Me.Label5.TabIndex = 113
        Me.Label5.Text = "MURA"
        '
        'txtMURA
        '
        Me.txtMURA.BackColor = System.Drawing.SystemColors.Window
        Me.txtMURA.Location = New System.Drawing.Point(254, 6)
        Me.txtMURA.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMURA.Name = "txtMURA"
        Me.txtMURA.ReadOnly = True
        Me.txtMURA.Size = New System.Drawing.Size(19, 22)
        Me.txtMURA.TabIndex = 114
        '
        'txtCP
        '
        Me.txtCP.BackColor = System.Drawing.SystemColors.Window
        Me.txtCP.Location = New System.Drawing.Point(254, 125)
        Me.txtCP.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCP.Name = "txtCP"
        Me.txtCP.ReadOnly = True
        Me.txtCP.Size = New System.Drawing.Size(19, 22)
        Me.txtCP.TabIndex = 116
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Location = New System.Drawing.Point(191, 127)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 12)
        Me.Label6.TabIndex = 115
        Me.Label6.Text = "Cell-Particle"
        '
        'txtSBP
        '
        Me.txtSBP.BackColor = System.Drawing.SystemColors.Window
        Me.txtSBP.Location = New System.Drawing.Point(153, 147)
        Me.txtSBP.Margin = New System.Windows.Forms.Padding(2)
        Me.txtSBP.Name = "txtSBP"
        Me.txtSBP.ReadOnly = True
        Me.txtSBP.Size = New System.Drawing.Size(19, 22)
        Me.txtSBP.TabIndex = 118
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Location = New System.Drawing.Point(102, 149)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 12)
        Me.Label7.TabIndex = 117
        Me.Label7.Text = "Small-BP"
        '
        'txtOmitBP
        '
        Me.txtOmitBP.BackColor = System.Drawing.SystemColors.Window
        Me.txtOmitBP.Location = New System.Drawing.Point(66, 147)
        Me.txtOmitBP.Margin = New System.Windows.Forms.Padding(2)
        Me.txtOmitBP.Name = "txtOmitBP"
        Me.txtOmitBP.ReadOnly = True
        Me.txtOmitBP.Size = New System.Drawing.Size(19, 22)
        Me.txtOmitBP.TabIndex = 120
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Location = New System.Drawing.Point(18, 150)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 12)
        Me.Label8.TabIndex = 119
        Me.Label8.Text = "Omit-BP"
        '
        'txtBB
        '
        Me.txtBB.BackColor = System.Drawing.SystemColors.Window
        Me.txtBB.Location = New System.Drawing.Point(468, 29)
        Me.txtBB.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBB.Name = "txtBB"
        Me.txtBB.ReadOnly = True
        Me.txtBB.Size = New System.Drawing.Size(19, 22)
        Me.txtBB.TabIndex = 124
        '
        'txtFG
        '
        Me.txtFG.BackColor = System.Drawing.SystemColors.Window
        Me.txtFG.Location = New System.Drawing.Point(468, 5)
        Me.txtFG.Margin = New System.Windows.Forms.Padding(2)
        Me.txtFG.Name = "txtFG"
        Me.txtFG.ReadOnly = True
        Me.txtFG.Size = New System.Drawing.Size(19, 22)
        Me.txtFG.TabIndex = 123
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.Location = New System.Drawing.Point(425, 32)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(39, 12)
        Me.Label11.TabIndex = 122
        Me.Label11.Text = "Bubble"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.SystemColors.Control
        Me.Label13.Location = New System.Drawing.Point(404, 11)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(60, 12)
        Me.Label13.TabIndex = 121
        Me.Label13.Text = "Frame-Glue"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.SystemColors.Control
        Me.Label14.Location = New System.Drawing.Point(31, 10)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(33, 12)
        Me.Label14.TabIndex = 72
        Me.Label14.Text = "GSDP"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.SystemColors.Control
        Me.Label17.Location = New System.Drawing.Point(117, 10)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(33, 12)
        Me.Label17.TabIndex = 77
        Me.Label17.Text = "GSBP"
        '
        'txtGSDP
        '
        Me.txtGSDP.BackColor = System.Drawing.SystemColors.Window
        Me.txtGSDP.Location = New System.Drawing.Point(66, 6)
        Me.txtGSDP.Margin = New System.Windows.Forms.Padding(2)
        Me.txtGSDP.Name = "txtGSDP"
        Me.txtGSDP.ReadOnly = True
        Me.txtGSDP.Size = New System.Drawing.Size(19, 22)
        Me.txtGSDP.TabIndex = 91
        '
        'txtGSBP
        '
        Me.txtGSBP.BackColor = System.Drawing.SystemColors.Window
        Me.txtGSBP.Location = New System.Drawing.Point(153, 5)
        Me.txtGSBP.Margin = New System.Windows.Forms.Padding(2)
        Me.txtGSBP.Name = "txtGSBP"
        Me.txtGSBP.ReadOnly = True
        Me.txtGSBP.Size = New System.Drawing.Size(19, 22)
        Me.txtGSBP.TabIndex = 96
        '
        'DlgDefectColor
        '
        Me.AcceptButton = Me.btnSave
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(509, 212)
        Me.Controls.Add(Me.txtBB)
        Me.Controls.Add(Me.txtFG)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtOmitBP)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtSBP)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtCP)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtMURA)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnDefault)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtHOL)
        Me.Controls.Add(Me.txtVOL)
        Me.Controls.Add(Me.txtHL)
        Me.Controls.Add(Me.txtVL)
        Me.Controls.Add(Me.txtXL)
        Me.Controls.Add(Me.txtBPDPn)
        Me.Controls.Add(Me.txtBPDPx)
        Me.Controls.Add(Me.txtBPDP3)
        Me.Controls.Add(Me.txtBPDP2)
        Me.Controls.Add(Me.txtMark)
        Me.Controls.Add(Me.txtBPn)
        Me.Controls.Add(Me.txtBPx)
        Me.Controls.Add(Me.txtBP3)
        Me.Controls.Add(Me.txtBP2)
        Me.Controls.Add(Me.txtGSBP)
        Me.Controls.Add(Me.txtBP1)
        Me.Controls.Add(Me.txtDPn)
        Me.Controls.Add(Me.txtDPx)
        Me.Controls.Add(Me.txtDP3)
        Me.Controls.Add(Me.txtGSDP)
        Me.Controls.Add(Me.txtDP2)
        Me.Controls.Add(Me.txtDP1)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DlgDefectColor"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Defect Color"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtDP1 As System.Windows.Forms.TextBox
    Friend WithEvents DlgColor As System.Windows.Forms.ColorDialog
    Friend WithEvents txtDP2 As System.Windows.Forms.TextBox
    Friend WithEvents txtDP3 As System.Windows.Forms.TextBox
    Friend WithEvents txtDPx As System.Windows.Forms.TextBox
    Friend WithEvents txtDPn As System.Windows.Forms.TextBox
    Friend WithEvents txtBPn As System.Windows.Forms.TextBox
    Friend WithEvents txtBPx As System.Windows.Forms.TextBox
    Friend WithEvents txtBP3 As System.Windows.Forms.TextBox
    Friend WithEvents txtBP2 As System.Windows.Forms.TextBox
    Friend WithEvents txtBP1 As System.Windows.Forms.TextBox
    Friend WithEvents txtBPDPn As System.Windows.Forms.TextBox
    Friend WithEvents txtBPDPx As System.Windows.Forms.TextBox
    Friend WithEvents txtBPDP3 As System.Windows.Forms.TextBox
    Friend WithEvents txtBPDP2 As System.Windows.Forms.TextBox
    Friend WithEvents txtMark As System.Windows.Forms.TextBox
    Friend WithEvents txtHOL As System.Windows.Forms.TextBox
    Friend WithEvents txtVOL As System.Windows.Forms.TextBox
    Friend WithEvents txtHL As System.Windows.Forms.TextBox
    Friend WithEvents txtVL As System.Windows.Forms.TextBox
    Friend WithEvents txtXL As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnDefault As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtMURA As System.Windows.Forms.TextBox
    Friend WithEvents txtCP As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtSBP As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtOmitBP As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtBB As System.Windows.Forms.TextBox
    Friend WithEvents txtFG As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtGSDP As System.Windows.Forms.TextBox
    Friend WithEvents txtGSBP As System.Windows.Forms.TextBox

End Class
