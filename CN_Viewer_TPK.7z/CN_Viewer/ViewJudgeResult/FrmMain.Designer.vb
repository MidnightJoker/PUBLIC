﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        Me.mnuMenu = New System.Windows.Forms.MenuStrip()
        Me.tsmFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenNotePadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSetting = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmPanelSize = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmDefectColor = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmDefectView = New System.Windows.Forms.ToolStripMenuItem()
        Me.labDP1 = New System.Windows.Forms.Label()
        Me.labBP1 = New System.Windows.Forms.Label()
        Me.txtBP1 = New System.Windows.Forms.Label()
        Me.txtDP1 = New System.Windows.Forms.Label()
        Me.labVL = New System.Windows.Forms.Label()
        Me.txtVL = New System.Windows.Forms.Label()
        Me.txtHL = New System.Windows.Forms.Label()
        Me.labHL = New System.Windows.Forms.Label()
        Me.txtHOL = New System.Windows.Forms.Label()
        Me.labHOL = New System.Windows.Forms.Label()
        Me.txtVOL = New System.Windows.Forms.Label()
        Me.labVOL = New System.Windows.Forms.Label()
        Me.txtDP2 = New System.Windows.Forms.Label()
        Me.txtBP2 = New System.Windows.Forms.Label()
        Me.labDP2 = New System.Windows.Forms.Label()
        Me.labBP2 = New System.Windows.Forms.Label()
        Me.txtBPDP2 = New System.Windows.Forms.Label()
        Me.labBPDP2 = New System.Windows.Forms.Label()
        Me.txtBPDP3 = New System.Windows.Forms.Label()
        Me.labBPDP3 = New System.Windows.Forms.Label()
        Me.txtDP3 = New System.Windows.Forms.Label()
        Me.txtBP3 = New System.Windows.Forms.Label()
        Me.labDP3 = New System.Windows.Forms.Label()
        Me.labBP3 = New System.Windows.Forms.Label()
        Me.txtBPDPx = New System.Windows.Forms.Label()
        Me.labBPDPx = New System.Windows.Forms.Label()
        Me.txtDPx = New System.Windows.Forms.Label()
        Me.txtBPx = New System.Windows.Forms.Label()
        Me.labDPx = New System.Windows.Forms.Label()
        Me.labBPx = New System.Windows.Forms.Label()
        Me.txtDPn = New System.Windows.Forms.Label()
        Me.labDPn = New System.Windows.Forms.Label()
        Me.txtBPn = New System.Windows.Forms.Label()
        Me.labBPn = New System.Windows.Forms.Label()
        Me.txtBPDPn = New System.Windows.Forms.Label()
        Me.labBPDPn = New System.Windows.Forms.Label()
        Me.txtXL = New System.Windows.Forms.Label()
        Me.labXL = New System.Windows.Forms.Label()
        Me.teeView = New System.Windows.Forms.TreeView()
        Me.grpJudgeInfo = New System.Windows.Forms.GroupBox()
        Me.txtPanelID = New System.Windows.Forms.TextBox()
        Me.txtMainDefect = New System.Windows.Forms.TextBox()
        Me.txtAgsRank = New System.Windows.Forms.TextBox()
        Me.txtCstRank = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label_AGSRank = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtSGBB = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtLBB = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtMBB = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtSBB = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtFG = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtOmitBP = New System.Windows.Forms.Label()
        Me.labOmitBP = New System.Windows.Forms.Label()
        Me.txtSBP = New System.Windows.Forms.Label()
        Me.labSBP = New System.Windows.Forms.Label()
        Me.txtCP = New System.Windows.Forms.Label()
        Me.labCP = New System.Windows.Forms.Label()
        Me.labMURA = New System.Windows.Forms.Label()
        Me.txtMURA = New System.Windows.Forms.Label()
        Me.txtBLDP = New System.Windows.Forms.Label()
        Me.txtGSBP = New System.Windows.Forms.Label()
        Me.labBLDP = New System.Windows.Forms.Label()
        Me.labGSBP = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdo9CCD = New System.Windows.Forms.RadioButton()
        Me.rdo4CCD = New System.Windows.Forms.RadioButton()
        Me.rdo2CCD = New System.Windows.Forms.RadioButton()
        Me.rdo3CCD = New System.Windows.Forms.RadioButton()
        Me.rdo1CCD = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chkBMMode = New System.Windows.Forms.CheckBox()
        Me.chkRotate = New System.Windows.Forms.CheckBox()
        Me.chkOverlap = New System.Windows.Forms.CheckBox()
        Me.chkCCD7 = New System.Windows.Forms.CheckBox()
        Me.chkCCD9 = New System.Windows.Forms.CheckBox()
        Me.chkCCD4 = New System.Windows.Forms.CheckBox()
        Me.chkCCD6 = New System.Windows.Forms.CheckBox()
        Me.chkCCD8 = New System.Windows.Forms.CheckBox()
        Me.chkCCD3 = New System.Windows.Forms.CheckBox()
        Me.chkCCD5 = New System.Windows.Forms.CheckBox()
        Me.chkCCD2 = New System.Windows.Forms.CheckBox()
        Me.chkCCD1 = New System.Windows.Forms.CheckBox()
        Me.ckbOpMode = New System.Windows.Forms.CheckBox()
        Me.btnMuraShow = New System.Windows.Forms.Button()
        Me.txtAoiJudgerResult = New System.Windows.Forms.TextBox()
        Me.rtbJudgeResultFile = New System.Windows.Forms.RichTextBox()
        Me.rbDetailInfo = New System.Windows.Forms.RadioButton()
        Me.rbMuraPartition = New System.Windows.Forms.RadioButton()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.rbRightView = New System.Windows.Forms.RadioButton()
        Me.rbNormalView = New System.Windows.Forms.RadioButton()
        Me.rbLeftView = New System.Windows.Forms.RadioButton()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.gbSettingTool = New System.Windows.Forms.GroupBox()
        Me.TabControl_ShowDefect = New System.Windows.Forms.TabControl()
        Me.TabPage_AOI = New System.Windows.Forms.TabPage()
        Me.grpDefectMapping = New System.Windows.Forms.GroupBox()
        Me.labPanelH = New System.Windows.Forms.Label()
        Me.labPanelW = New System.Windows.Forms.Label()
        Me.labPanelMinH = New System.Windows.Forms.Label()
        Me.labPanelMinW = New System.Windows.Forms.Label()
        Me.picView = New System.Windows.Forms.PictureBox()
        Me.TabPage_Luminance = New System.Windows.Forms.TabPage()
        Me.lb_MeasureParam = New System.Windows.Forms.Label()
        Me.dgv_MeasureResult = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbo_MeasurePatternName = New System.Windows.Forms.ComboBox()
        Me.SplitContainer_OKNGShow = New System.Windows.Forms.SplitContainer()
        Me.txtLuminanceResult = New System.Windows.Forms.TextBox()
        Me.SplitContainer_OKNGTitle = New System.Windows.Forms.SplitContainer()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtAoiJudgerAGSResult = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.labDfImgMsg = New System.Windows.Forms.Label()
        Me.picDfImg = New System.Windows.Forms.PictureBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.lb_MeasureAve = New System.Windows.Forms.Label()
        Me.lb_Measure5U = New System.Windows.Forms.Label()
        Me.lb_Measure13U = New System.Windows.Forms.Label()
        Me.txt_MeasureAvg = New System.Windows.Forms.TextBox()
        Me.txt_Measure5U = New System.Windows.Forms.TextBox()
        Me.txt_Measure13U = New System.Windows.Forms.TextBox()
        Me.mnuMenu.SuspendLayout()
        Me.grpJudgeInfo.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.gbSettingTool.SuspendLayout()
        Me.TabControl_ShowDefect.SuspendLayout()
        Me.TabPage_AOI.SuspendLayout()
        Me.grpDefectMapping.SuspendLayout()
        CType(Me.picView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Luminance.SuspendLayout()
        CType(Me.dgv_MeasureResult, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SplitContainer_OKNGShow, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer_OKNGShow.Panel1.SuspendLayout()
        Me.SplitContainer_OKNGShow.Panel2.SuspendLayout()
        Me.SplitContainer_OKNGShow.SuspendLayout()
        CType(Me.SplitContainer_OKNGTitle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer_OKNGTitle.Panel1.SuspendLayout()
        Me.SplitContainer_OKNGTitle.Panel2.SuspendLayout()
        Me.SplitContainer_OKNGTitle.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.picDfImg, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnuMenu
        '
        Me.mnuMenu.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.mnuMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmFile, Me.tsmSetting})
        Me.mnuMenu.Location = New System.Drawing.Point(0, 0)
        Me.mnuMenu.Name = "mnuMenu"
        Me.mnuMenu.Padding = New System.Windows.Forms.Padding(5, 2, 0, 2)
        Me.mnuMenu.Size = New System.Drawing.Size(1359, 27)
        Me.mnuMenu.TabIndex = 0
        Me.mnuMenu.Text = "MenuStrip1"
        '
        'tsmFile
        '
        Me.tsmFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmOpen, Me.OpenNotePadToolStripMenuItem, Me.tsmExit})
        Me.tsmFile.Name = "tsmFile"
        Me.tsmFile.Size = New System.Drawing.Size(47, 23)
        Me.tsmFile.Text = "File"
        '
        'tsmOpen
        '
        Me.tsmOpen.Name = "tsmOpen"
        Me.tsmOpen.Size = New System.Drawing.Size(224, 26)
        Me.tsmOpen.Text = "Open"
        '
        'OpenNotePadToolStripMenuItem
        '
        Me.OpenNotePadToolStripMenuItem.Name = "OpenNotePadToolStripMenuItem"
        Me.OpenNotePadToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.OpenNotePadToolStripMenuItem.Text = "OpenNotePad"
        '
        'tsmExit
        '
        Me.tsmExit.Name = "tsmExit"
        Me.tsmExit.Size = New System.Drawing.Size(224, 26)
        Me.tsmExit.Text = "Exit"
        '
        'tsmSetting
        '
        Me.tsmSetting.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmPanelSize, Me.tsmDefectColor, Me.tsmDefectView})
        Me.tsmSetting.Name = "tsmSetting"
        Me.tsmSetting.Size = New System.Drawing.Size(73, 23)
        Me.tsmSetting.Text = "Setting"
        '
        'tsmPanelSize
        '
        Me.tsmPanelSize.Name = "tsmPanelSize"
        Me.tsmPanelSize.Size = New System.Drawing.Size(224, 26)
        Me.tsmPanelSize.Text = "Panel Size"
        '
        'tsmDefectColor
        '
        Me.tsmDefectColor.Name = "tsmDefectColor"
        Me.tsmDefectColor.Size = New System.Drawing.Size(224, 26)
        Me.tsmDefectColor.Text = "Defect Color"
        '
        'tsmDefectView
        '
        Me.tsmDefectView.Name = "tsmDefectView"
        Me.tsmDefectView.Size = New System.Drawing.Size(224, 26)
        Me.tsmDefectView.Text = "Defect View"
        '
        'labDP1
        '
        Me.labDP1.AutoSize = True
        Me.labDP1.BackColor = System.Drawing.Color.LawnGreen
        Me.labDP1.Location = New System.Drawing.Point(56, 46)
        Me.labDP1.Name = "labDP1"
        Me.labDP1.Size = New System.Drawing.Size(25, 15)
        Me.labDP1.TabIndex = 7
        Me.labDP1.Text = "DP"
        '
        'labBP1
        '
        Me.labBP1.AutoSize = True
        Me.labBP1.BackColor = System.Drawing.Color.Red
        Me.labBP1.Location = New System.Drawing.Point(56, 188)
        Me.labBP1.Name = "labBP1"
        Me.labBP1.Size = New System.Drawing.Size(24, 15)
        Me.labBP1.TabIndex = 6
        Me.labBP1.Text = "BP"
        '
        'txtBP1
        '
        Me.txtBP1.AutoSize = True
        Me.txtBP1.Location = New System.Drawing.Point(83, 188)
        Me.txtBP1.Name = "txtBP1"
        Me.txtBP1.Size = New System.Drawing.Size(14, 15)
        Me.txtBP1.TabIndex = 12
        Me.txtBP1.Text = "0"
        '
        'txtDP1
        '
        Me.txtDP1.AutoSize = True
        Me.txtDP1.Location = New System.Drawing.Point(83, 46)
        Me.txtDP1.Name = "txtDP1"
        Me.txtDP1.Size = New System.Drawing.Size(14, 15)
        Me.txtDP1.TabIndex = 13
        Me.txtDP1.Text = "0"
        '
        'labVL
        '
        Me.labVL.AutoSize = True
        Me.labVL.BackColor = System.Drawing.Color.White
        Me.labVL.Location = New System.Drawing.Point(143, 304)
        Me.labVL.Name = "labVL"
        Me.labVL.Size = New System.Drawing.Size(48, 15)
        Me.labVL.TabIndex = 14
        Me.labVL.Text = "V-Line"
        '
        'txtVL
        '
        Me.txtVL.AutoSize = True
        Me.txtVL.Location = New System.Drawing.Point(196, 304)
        Me.txtVL.Name = "txtVL"
        Me.txtVL.Size = New System.Drawing.Size(14, 15)
        Me.txtVL.TabIndex = 15
        Me.txtVL.Text = "0"
        '
        'txtHL
        '
        Me.txtHL.AutoSize = True
        Me.txtHL.Location = New System.Drawing.Point(196, 329)
        Me.txtHL.Name = "txtHL"
        Me.txtHL.Size = New System.Drawing.Size(14, 15)
        Me.txtHL.TabIndex = 17
        Me.txtHL.Text = "0"
        '
        'labHL
        '
        Me.labHL.AutoSize = True
        Me.labHL.BackColor = System.Drawing.Color.White
        Me.labHL.Location = New System.Drawing.Point(143, 329)
        Me.labHL.Name = "labHL"
        Me.labHL.Size = New System.Drawing.Size(48, 15)
        Me.labHL.TabIndex = 16
        Me.labHL.Text = "H-Line"
        '
        'txtHOL
        '
        Me.txtHOL.AutoSize = True
        Me.txtHOL.Location = New System.Drawing.Point(196, 375)
        Me.txtHOL.Name = "txtHOL"
        Me.txtHOL.Size = New System.Drawing.Size(14, 15)
        Me.txtHOL.TabIndex = 37
        Me.txtHOL.Text = "0"
        '
        'labHOL
        '
        Me.labHOL.AutoSize = True
        Me.labHOL.BackColor = System.Drawing.Color.White
        Me.labHOL.Location = New System.Drawing.Point(139, 375)
        Me.labHOL.Name = "labHOL"
        Me.labHOL.Size = New System.Drawing.Size(52, 15)
        Me.labHOL.TabIndex = 36
        Me.labHOL.Text = "H-Open"
        '
        'txtVOL
        '
        Me.txtVOL.AutoSize = True
        Me.txtVOL.Location = New System.Drawing.Point(196, 352)
        Me.txtVOL.Name = "txtVOL"
        Me.txtVOL.Size = New System.Drawing.Size(14, 15)
        Me.txtVOL.TabIndex = 35
        Me.txtVOL.Text = "0"
        '
        'labVOL
        '
        Me.labVOL.AutoSize = True
        Me.labVOL.BackColor = System.Drawing.Color.White
        Me.labVOL.Location = New System.Drawing.Point(139, 352)
        Me.labVOL.Name = "labVOL"
        Me.labVOL.Size = New System.Drawing.Size(52, 15)
        Me.labVOL.TabIndex = 34
        Me.labVOL.Text = "V-Open"
        '
        'txtDP2
        '
        Me.txtDP2.AutoSize = True
        Me.txtDP2.Location = New System.Drawing.Point(83, 69)
        Me.txtDP2.Name = "txtDP2"
        Me.txtDP2.Size = New System.Drawing.Size(14, 15)
        Me.txtDP2.TabIndex = 33
        Me.txtDP2.Text = "0"
        '
        'txtBP2
        '
        Me.txtBP2.AutoSize = True
        Me.txtBP2.Location = New System.Drawing.Point(83, 210)
        Me.txtBP2.Name = "txtBP2"
        Me.txtBP2.Size = New System.Drawing.Size(14, 15)
        Me.txtBP2.TabIndex = 32
        Me.txtBP2.Text = "0"
        '
        'labDP2
        '
        Me.labDP2.AutoSize = True
        Me.labDP2.BackColor = System.Drawing.Color.LawnGreen
        Me.labDP2.Location = New System.Drawing.Point(28, 69)
        Me.labDP2.Name = "labDP2"
        Me.labDP2.Size = New System.Drawing.Size(53, 15)
        Me.labDP2.TabIndex = 31
        Me.labDP2.Text = "DP-Pair"
        '
        'labBP2
        '
        Me.labBP2.AutoSize = True
        Me.labBP2.BackColor = System.Drawing.Color.Red
        Me.labBP2.Location = New System.Drawing.Point(28, 210)
        Me.labBP2.Name = "labBP2"
        Me.labBP2.Size = New System.Drawing.Size(52, 15)
        Me.labBP2.TabIndex = 30
        Me.labBP2.Text = "BP-Pair"
        '
        'txtBPDP2
        '
        Me.txtBPDP2.AutoSize = True
        Me.txtBPDP2.Location = New System.Drawing.Point(211, 50)
        Me.txtBPDP2.Name = "txtBPDP2"
        Me.txtBPDP2.Size = New System.Drawing.Size(14, 15)
        Me.txtBPDP2.TabIndex = 41
        Me.txtBPDP2.Text = "0"
        '
        'labBPDP2
        '
        Me.labBPDP2.AutoSize = True
        Me.labBPDP2.BackColor = System.Drawing.Color.Yellow
        Me.labBPDP2.Location = New System.Drawing.Point(137, 50)
        Me.labBPDP2.Name = "labBPDP2"
        Me.labBPDP2.Size = New System.Drawing.Size(70, 15)
        Me.labBPDP2.TabIndex = 40
        Me.labBPDP2.Text = "BPDP-Pair"
        '
        'txtBPDP3
        '
        Me.txtBPDP3.AutoSize = True
        Me.txtBPDP3.Location = New System.Drawing.Point(211, 75)
        Me.txtBPDP3.Name = "txtBPDP3"
        Me.txtBPDP3.Size = New System.Drawing.Size(14, 15)
        Me.txtBPDP3.TabIndex = 47
        Me.txtBPDP3.Text = "0"
        '
        'labBPDP3
        '
        Me.labBPDP3.AutoSize = True
        Me.labBPDP3.BackColor = System.Drawing.Color.Yellow
        Me.labBPDP3.Location = New System.Drawing.Point(129, 75)
        Me.labBPDP3.Name = "labBPDP3"
        Me.labBPDP3.Size = New System.Drawing.Size(79, 15)
        Me.labBPDP3.TabIndex = 46
        Me.labBPDP3.Text = "3BPDP-ADJ"
        '
        'txtDP3
        '
        Me.txtDP3.AutoSize = True
        Me.txtDP3.Location = New System.Drawing.Point(83, 94)
        Me.txtDP3.Name = "txtDP3"
        Me.txtDP3.Size = New System.Drawing.Size(14, 15)
        Me.txtDP3.TabIndex = 45
        Me.txtDP3.Text = "0"
        '
        'txtBP3
        '
        Me.txtBP3.AutoSize = True
        Me.txtBP3.Location = New System.Drawing.Point(83, 235)
        Me.txtBP3.Name = "txtBP3"
        Me.txtBP3.Size = New System.Drawing.Size(14, 15)
        Me.txtBP3.TabIndex = 44
        Me.txtBP3.Text = "0"
        '
        'labDP3
        '
        Me.labDP3.AutoSize = True
        Me.labDP3.BackColor = System.Drawing.Color.LawnGreen
        Me.labDP3.Location = New System.Drawing.Point(19, 94)
        Me.labDP3.Name = "labDP3"
        Me.labDP3.Size = New System.Drawing.Size(62, 15)
        Me.labDP3.TabIndex = 43
        Me.labDP3.Text = "3DP-ADJ"
        '
        'labBP3
        '
        Me.labBP3.AutoSize = True
        Me.labBP3.BackColor = System.Drawing.Color.Red
        Me.labBP3.Location = New System.Drawing.Point(19, 235)
        Me.labBP3.Name = "labBP3"
        Me.labBP3.Size = New System.Drawing.Size(61, 15)
        Me.labBP3.TabIndex = 42
        Me.labBP3.Text = "3BP-ADJ"
        '
        'txtBPDPx
        '
        Me.txtBPDPx.AutoSize = True
        Me.txtBPDPx.Location = New System.Drawing.Point(211, 99)
        Me.txtBPDPx.Name = "txtBPDPx"
        Me.txtBPDPx.Size = New System.Drawing.Size(14, 15)
        Me.txtBPDPx.TabIndex = 53
        Me.txtBPDPx.Text = "0"
        '
        'labBPDPx
        '
        Me.labBPDPx.AutoSize = True
        Me.labBPDPx.BackColor = System.Drawing.Color.Yellow
        Me.labBPDPx.Location = New System.Drawing.Point(121, 99)
        Me.labBPDPx.Name = "labBPDPx"
        Me.labBPDPx.Size = New System.Drawing.Size(87, 15)
        Me.labBPDPx.TabIndex = 52
        Me.labBPDPx.Text = "BPDP-Cluster"
        '
        'txtDPx
        '
        Me.txtDPx.AutoSize = True
        Me.txtDPx.Location = New System.Drawing.Point(83, 118)
        Me.txtDPx.Name = "txtDPx"
        Me.txtDPx.Size = New System.Drawing.Size(14, 15)
        Me.txtDPx.TabIndex = 51
        Me.txtDPx.Text = "0"
        '
        'txtBPx
        '
        Me.txtBPx.AutoSize = True
        Me.txtBPx.Location = New System.Drawing.Point(83, 259)
        Me.txtBPx.Name = "txtBPx"
        Me.txtBPx.Size = New System.Drawing.Size(14, 15)
        Me.txtBPx.TabIndex = 50
        Me.txtBPx.Text = "0"
        '
        'labDPx
        '
        Me.labDPx.AutoSize = True
        Me.labDPx.BackColor = System.Drawing.Color.LawnGreen
        Me.labDPx.Location = New System.Drawing.Point(11, 118)
        Me.labDPx.Name = "labDPx"
        Me.labDPx.Size = New System.Drawing.Size(70, 15)
        Me.labDPx.TabIndex = 49
        Me.labDPx.Text = "DP-Cluster"
        '
        'labBPx
        '
        Me.labBPx.AutoSize = True
        Me.labBPx.BackColor = System.Drawing.Color.Red
        Me.labBPx.Location = New System.Drawing.Point(11, 259)
        Me.labBPx.Name = "labBPx"
        Me.labBPx.Size = New System.Drawing.Size(69, 15)
        Me.labBPx.TabIndex = 48
        Me.labBPx.Text = "BP-Cluster"
        '
        'txtDPn
        '
        Me.txtDPn.AutoSize = True
        Me.txtDPn.Location = New System.Drawing.Point(83, 140)
        Me.txtDPn.Name = "txtDPn"
        Me.txtDPn.Size = New System.Drawing.Size(14, 15)
        Me.txtDPn.TabIndex = 55
        Me.txtDPn.Text = "0"
        '
        'labDPn
        '
        Me.labDPn.AutoSize = True
        Me.labDPn.BackColor = System.Drawing.Color.LawnGreen
        Me.labDPn.Location = New System.Drawing.Point(24, 140)
        Me.labDPn.Name = "labDPn"
        Me.labDPn.Size = New System.Drawing.Size(57, 15)
        Me.labDPn.TabIndex = 54
        Me.labDPn.Text = "DP-Near"
        '
        'txtBPn
        '
        Me.txtBPn.AutoSize = True
        Me.txtBPn.Location = New System.Drawing.Point(83, 281)
        Me.txtBPn.Name = "txtBPn"
        Me.txtBPn.Size = New System.Drawing.Size(14, 15)
        Me.txtBPn.TabIndex = 57
        Me.txtBPn.Text = "0"
        '
        'labBPn
        '
        Me.labBPn.AutoSize = True
        Me.labBPn.BackColor = System.Drawing.Color.Red
        Me.labBPn.Location = New System.Drawing.Point(24, 281)
        Me.labBPn.Name = "labBPn"
        Me.labBPn.Size = New System.Drawing.Size(56, 15)
        Me.labBPn.TabIndex = 56
        Me.labBPn.Text = "BP-Near"
        '
        'txtBPDPn
        '
        Me.txtBPDPn.AutoSize = True
        Me.txtBPDPn.Location = New System.Drawing.Point(211, 121)
        Me.txtBPDPn.Name = "txtBPDPn"
        Me.txtBPDPn.Size = New System.Drawing.Size(14, 15)
        Me.txtBPDPn.TabIndex = 59
        Me.txtBPDPn.Text = "0"
        '
        'labBPDPn
        '
        Me.labBPDPn.AutoSize = True
        Me.labBPDPn.BackColor = System.Drawing.Color.Yellow
        Me.labBPDPn.Location = New System.Drawing.Point(135, 121)
        Me.labBPDPn.Name = "labBPDPn"
        Me.labBPDPn.Size = New System.Drawing.Size(74, 15)
        Me.labBPDPn.TabIndex = 58
        Me.labBPDPn.Text = "BPDP-Near"
        '
        'txtXL
        '
        Me.txtXL.AutoSize = True
        Me.txtXL.Location = New System.Drawing.Point(196, 281)
        Me.txtXL.Name = "txtXL"
        Me.txtXL.Size = New System.Drawing.Size(14, 15)
        Me.txtXL.TabIndex = 61
        Me.txtXL.Text = "0"
        '
        'labXL
        '
        Me.labXL.AutoSize = True
        Me.labXL.BackColor = System.Drawing.Color.White
        Me.labXL.Location = New System.Drawing.Point(137, 281)
        Me.labXL.Name = "labXL"
        Me.labXL.Size = New System.Drawing.Size(53, 15)
        Me.labXL.TabIndex = 60
        Me.labXL.Text = "X-Short"
        '
        'teeView
        '
        Me.teeView.Location = New System.Drawing.Point(529, 36)
        Me.teeView.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.teeView.Name = "teeView"
        Me.teeView.ShowNodeToolTips = True
        Me.teeView.Size = New System.Drawing.Size(517, 118)
        Me.teeView.TabIndex = 3
        '
        'grpJudgeInfo
        '
        Me.grpJudgeInfo.Controls.Add(Me.txtPanelID)
        Me.grpJudgeInfo.Controls.Add(Me.txtMainDefect)
        Me.grpJudgeInfo.Controls.Add(Me.txtAgsRank)
        Me.grpJudgeInfo.Controls.Add(Me.txtCstRank)
        Me.grpJudgeInfo.Controls.Add(Me.Label7)
        Me.grpJudgeInfo.Controls.Add(Me.Label_AGSRank)
        Me.grpJudgeInfo.Controls.Add(Me.Label1)
        Me.grpJudgeInfo.Controls.Add(Me.Label3)
        Me.grpJudgeInfo.Location = New System.Drawing.Point(8, 28)
        Me.grpJudgeInfo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grpJudgeInfo.Name = "grpJudgeInfo"
        Me.grpJudgeInfo.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.grpJudgeInfo.Size = New System.Drawing.Size(516, 75)
        Me.grpJudgeInfo.TabIndex = 63
        Me.grpJudgeInfo.TabStop = False
        Me.grpJudgeInfo.Text = "Judge Information"
        '
        'txtPanelID
        '
        Me.txtPanelID.Enabled = False
        Me.txtPanelID.Location = New System.Drawing.Point(5, 38)
        Me.txtPanelID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtPanelID.Name = "txtPanelID"
        Me.txtPanelID.Size = New System.Drawing.Size(184, 25)
        Me.txtPanelID.TabIndex = 24
        '
        'txtMainDefect
        '
        Me.txtMainDefect.Enabled = False
        Me.txtMainDefect.Location = New System.Drawing.Point(320, 38)
        Me.txtMainDefect.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtMainDefect.Name = "txtMainDefect"
        Me.txtMainDefect.Size = New System.Drawing.Size(183, 25)
        Me.txtMainDefect.TabIndex = 27
        '
        'txtAgsRank
        '
        Me.txtAgsRank.Enabled = False
        Me.txtAgsRank.Location = New System.Drawing.Point(193, 38)
        Me.txtAgsRank.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtAgsRank.Name = "txtAgsRank"
        Me.txtAgsRank.Size = New System.Drawing.Size(56, 25)
        Me.txtAgsRank.TabIndex = 66
        '
        'txtCstRank
        '
        Me.txtCstRank.Enabled = False
        Me.txtCstRank.Location = New System.Drawing.Point(257, 38)
        Me.txtCstRank.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtCstRank.Name = "txtCstRank"
        Me.txtCstRank.Size = New System.Drawing.Size(56, 25)
        Me.txtCstRank.TabIndex = 26
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(269, 19)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(33, 15)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "CST"
        '
        'Label_AGSRank
        '
        Me.Label_AGSRank.AutoSize = True
        Me.Label_AGSRank.Location = New System.Drawing.Point(204, 19)
        Me.Label_AGSRank.Name = "Label_AGSRank"
        Me.Label_AGSRank.Size = New System.Drawing.Size(35, 15)
        Me.Label_AGSRank.TabIndex = 18
        Me.Label_AGSRank.Text = "AGS"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("新細明體", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.Location = New System.Drawing.Point(80, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 15)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Panel ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(372, 19)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 15)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "MainDefect"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtSGBB)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.txtLBB)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.txtMBB)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.txtSBB)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.txtFG)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.txtOmitBP)
        Me.GroupBox2.Controls.Add(Me.labOmitBP)
        Me.GroupBox2.Controls.Add(Me.txtSBP)
        Me.GroupBox2.Controls.Add(Me.labSBP)
        Me.GroupBox2.Controls.Add(Me.txtCP)
        Me.GroupBox2.Controls.Add(Me.labCP)
        Me.GroupBox2.Controls.Add(Me.labMURA)
        Me.GroupBox2.Controls.Add(Me.txtMURA)
        Me.GroupBox2.Controls.Add(Me.txtXL)
        Me.GroupBox2.Controls.Add(Me.labXL)
        Me.GroupBox2.Controls.Add(Me.txtBPDPn)
        Me.GroupBox2.Controls.Add(Me.labBPDPn)
        Me.GroupBox2.Controls.Add(Me.txtBPn)
        Me.GroupBox2.Controls.Add(Me.labBPn)
        Me.GroupBox2.Controls.Add(Me.txtDPn)
        Me.GroupBox2.Controls.Add(Me.labDPn)
        Me.GroupBox2.Controls.Add(Me.txtBPDPx)
        Me.GroupBox2.Controls.Add(Me.labBPDPx)
        Me.GroupBox2.Controls.Add(Me.txtDPx)
        Me.GroupBox2.Controls.Add(Me.txtBPx)
        Me.GroupBox2.Controls.Add(Me.labDPx)
        Me.GroupBox2.Controls.Add(Me.labBPx)
        Me.GroupBox2.Controls.Add(Me.txtBPDP3)
        Me.GroupBox2.Controls.Add(Me.labBPDP3)
        Me.GroupBox2.Controls.Add(Me.txtDP3)
        Me.GroupBox2.Controls.Add(Me.txtBP3)
        Me.GroupBox2.Controls.Add(Me.labDP3)
        Me.GroupBox2.Controls.Add(Me.labBP3)
        Me.GroupBox2.Controls.Add(Me.txtBPDP2)
        Me.GroupBox2.Controls.Add(Me.labBPDP2)
        Me.GroupBox2.Controls.Add(Me.txtHOL)
        Me.GroupBox2.Controls.Add(Me.labHOL)
        Me.GroupBox2.Controls.Add(Me.txtVOL)
        Me.GroupBox2.Controls.Add(Me.labVOL)
        Me.GroupBox2.Controls.Add(Me.txtDP2)
        Me.GroupBox2.Controls.Add(Me.txtBP2)
        Me.GroupBox2.Controls.Add(Me.labDP2)
        Me.GroupBox2.Controls.Add(Me.labBP2)
        Me.GroupBox2.Controls.Add(Me.txtHL)
        Me.GroupBox2.Controls.Add(Me.labHL)
        Me.GroupBox2.Controls.Add(Me.txtVL)
        Me.GroupBox2.Controls.Add(Me.labVL)
        Me.GroupBox2.Controls.Add(Me.txtBLDP)
        Me.GroupBox2.Controls.Add(Me.txtDP1)
        Me.GroupBox2.Controls.Add(Me.txtGSBP)
        Me.GroupBox2.Controls.Add(Me.txtBP1)
        Me.GroupBox2.Controls.Add(Me.labBLDP)
        Me.GroupBox2.Controls.Add(Me.labGSBP)
        Me.GroupBox2.Controls.Add(Me.labDP1)
        Me.GroupBox2.Controls.Add(Me.labBP1)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 352)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Size = New System.Drawing.Size(243, 402)
        Me.GroupBox2.TabIndex = 64
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Defect Count"
        '
        'txtSGBB
        '
        Me.txtSGBB.AutoSize = True
        Me.txtSGBB.Location = New System.Drawing.Point(213, 261)
        Me.txtSGBB.Name = "txtSGBB"
        Me.txtSGBB.Size = New System.Drawing.Size(14, 15)
        Me.txtSGBB.TabIndex = 79
        Me.txtSGBB.Text = "0"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Blue
        Me.Label13.Location = New System.Drawing.Point(103, 261)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(99, 15)
        Me.Label13.TabIndex = 78
        Me.Label13.Text = "S-Grade-Bubble"
        '
        'txtLBB
        '
        Me.txtLBB.AutoSize = True
        Me.txtLBB.Location = New System.Drawing.Point(213, 241)
        Me.txtLBB.Name = "txtLBB"
        Me.txtLBB.Size = New System.Drawing.Size(14, 15)
        Me.txtLBB.TabIndex = 77
        Me.txtLBB.Text = "0"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Blue
        Me.Label11.Location = New System.Drawing.Point(117, 239)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(85, 15)
        Me.Label11.TabIndex = 76
        Me.Label11.Text = "Large-Bubble"
        '
        'txtMBB
        '
        Me.txtMBB.AutoSize = True
        Me.txtMBB.Location = New System.Drawing.Point(213, 218)
        Me.txtMBB.Name = "txtMBB"
        Me.txtMBB.Size = New System.Drawing.Size(14, 15)
        Me.txtMBB.TabIndex = 75
        Me.txtMBB.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Blue
        Me.Label8.Location = New System.Drawing.Point(109, 215)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(93, 15)
        Me.Label8.TabIndex = 74
        Me.Label8.Text = "Middle-Bubble"
        '
        'txtSBB
        '
        Me.txtSBB.AutoSize = True
        Me.txtSBB.Location = New System.Drawing.Point(213, 192)
        Me.txtSBB.Name = "txtSBB"
        Me.txtSBB.Size = New System.Drawing.Size(14, 15)
        Me.txtSBB.TabIndex = 73
        Me.txtSBB.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Blue
        Me.Label6.Location = New System.Drawing.Point(119, 191)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(85, 15)
        Me.Label6.TabIndex = 72
        Me.Label6.Text = "Small-Bubble"
        '
        'txtFG
        '
        Me.txtFG.AutoSize = True
        Me.txtFG.Location = New System.Drawing.Point(213, 169)
        Me.txtFG.Name = "txtFG"
        Me.txtFG.Size = New System.Drawing.Size(14, 15)
        Me.txtFG.TabIndex = 71
        Me.txtFG.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Blue
        Me.Label9.Location = New System.Drawing.Point(133, 169)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(72, 15)
        Me.Label9.TabIndex = 70
        Me.Label9.Text = "Frame-glue"
        '
        'txtOmitBP
        '
        Me.txtOmitBP.AutoSize = True
        Me.txtOmitBP.Location = New System.Drawing.Point(83, 335)
        Me.txtOmitBP.Name = "txtOmitBP"
        Me.txtOmitBP.Size = New System.Drawing.Size(14, 15)
        Me.txtOmitBP.TabIndex = 69
        Me.txtOmitBP.Text = "0"
        '
        'labOmitBP
        '
        Me.labOmitBP.AutoSize = True
        Me.labOmitBP.BackColor = System.Drawing.Color.IndianRed
        Me.labOmitBP.Location = New System.Drawing.Point(21, 335)
        Me.labOmitBP.Name = "labOmitBP"
        Me.labOmitBP.Size = New System.Drawing.Size(57, 15)
        Me.labOmitBP.TabIndex = 68
        Me.labOmitBP.Text = "Omit BP"
        '
        'txtSBP
        '
        Me.txtSBP.AutoSize = True
        Me.txtSBP.Location = New System.Drawing.Point(85, 308)
        Me.txtSBP.Name = "txtSBP"
        Me.txtSBP.Size = New System.Drawing.Size(14, 15)
        Me.txtSBP.TabIndex = 67
        Me.txtSBP.Text = "0"
        '
        'labSBP
        '
        Me.labSBP.AutoSize = True
        Me.labSBP.BackColor = System.Drawing.Color.Fuchsia
        Me.labSBP.Location = New System.Drawing.Point(16, 308)
        Me.labSBP.Name = "labSBP"
        Me.labSBP.Size = New System.Drawing.Size(62, 15)
        Me.labSBP.TabIndex = 66
        Me.labSBP.Text = "Small-BP"
        '
        'txtCP
        '
        Me.txtCP.AutoSize = True
        Me.txtCP.Location = New System.Drawing.Point(211, 141)
        Me.txtCP.Name = "txtCP"
        Me.txtCP.Size = New System.Drawing.Size(14, 15)
        Me.txtCP.TabIndex = 65
        Me.txtCP.Text = "0"
        '
        'labCP
        '
        Me.labCP.AutoSize = True
        Me.labCP.BackColor = System.Drawing.Color.Orange
        Me.labCP.Location = New System.Drawing.Point(131, 141)
        Me.labCP.Name = "labCP"
        Me.labCP.Size = New System.Drawing.Size(78, 15)
        Me.labCP.TabIndex = 64
        Me.labCP.Text = "Cell-Particle"
        '
        'labMURA
        '
        Me.labMURA.AutoSize = True
        Me.labMURA.BackColor = System.Drawing.Color.Cyan
        Me.labMURA.Location = New System.Drawing.Point(159, 28)
        Me.labMURA.Name = "labMURA"
        Me.labMURA.Size = New System.Drawing.Size(49, 15)
        Me.labMURA.TabIndex = 63
        Me.labMURA.Text = "MURA"
        '
        'txtMURA
        '
        Me.txtMURA.AutoSize = True
        Me.txtMURA.Location = New System.Drawing.Point(211, 28)
        Me.txtMURA.Name = "txtMURA"
        Me.txtMURA.Size = New System.Drawing.Size(14, 15)
        Me.txtMURA.TabIndex = 62
        Me.txtMURA.Text = "0"
        '
        'txtBLDP
        '
        Me.txtBLDP.AutoSize = True
        Me.txtBLDP.Location = New System.Drawing.Point(83, 28)
        Me.txtBLDP.Name = "txtBLDP"
        Me.txtBLDP.Size = New System.Drawing.Size(14, 15)
        Me.txtBLDP.TabIndex = 13
        Me.txtBLDP.Text = "0"
        '
        'txtGSBP
        '
        Me.txtGSBP.AutoSize = True
        Me.txtGSBP.Location = New System.Drawing.Point(83, 169)
        Me.txtGSBP.Name = "txtGSBP"
        Me.txtGSBP.Size = New System.Drawing.Size(14, 15)
        Me.txtGSBP.TabIndex = 12
        Me.txtGSBP.Text = "0"
        '
        'labBLDP
        '
        Me.labBLDP.AutoSize = True
        Me.labBLDP.BackColor = System.Drawing.Color.LawnGreen
        Me.labBLDP.Location = New System.Drawing.Point(39, 28)
        Me.labBLDP.Name = "labBLDP"
        Me.labBLDP.Size = New System.Drawing.Size(43, 15)
        Me.labBLDP.TabIndex = 7
        Me.labBLDP.Text = "BLDP"
        '
        'labGSBP
        '
        Me.labGSBP.AutoSize = True
        Me.labGSBP.BackColor = System.Drawing.Color.Red
        Me.labGSBP.Location = New System.Drawing.Point(37, 169)
        Me.labGSBP.Name = "labGSBP"
        Me.labGSBP.Size = New System.Drawing.Size(42, 15)
        Me.labGSBP.TabIndex = 6
        Me.labGSBP.Text = "GSBP"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdo9CCD)
        Me.GroupBox1.Controls.Add(Me.rdo4CCD)
        Me.GroupBox1.Controls.Add(Me.rdo2CCD)
        Me.GroupBox1.Controls.Add(Me.rdo3CCD)
        Me.GroupBox1.Controls.Add(Me.rdo1CCD)
        Me.GroupBox1.Location = New System.Drawing.Point(15, 69)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(245, 100)
        Me.GroupBox1.TabIndex = 66
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "CCD Mode"
        '
        'rdo9CCD
        '
        Me.rdo9CCD.AutoSize = True
        Me.rdo9CCD.Location = New System.Drawing.Point(87, 49)
        Me.rdo9CCD.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rdo9CCD.Name = "rdo9CCD"
        Me.rdo9CCD.Size = New System.Drawing.Size(63, 19)
        Me.rdo9CCD.TabIndex = 0
        Me.rdo9CCD.Text = "9CCD"
        Me.rdo9CCD.UseVisualStyleBackColor = True
        '
        'rdo4CCD
        '
        Me.rdo4CCD.AutoSize = True
        Me.rdo4CCD.Location = New System.Drawing.Point(12, 51)
        Me.rdo4CCD.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rdo4CCD.Name = "rdo4CCD"
        Me.rdo4CCD.Size = New System.Drawing.Size(63, 19)
        Me.rdo4CCD.TabIndex = 0
        Me.rdo4CCD.Text = "4CCD"
        Me.rdo4CCD.UseVisualStyleBackColor = True
        '
        'rdo2CCD
        '
        Me.rdo2CCD.AutoSize = True
        Me.rdo2CCD.Location = New System.Drawing.Point(85, 22)
        Me.rdo2CCD.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rdo2CCD.Name = "rdo2CCD"
        Me.rdo2CCD.Size = New System.Drawing.Size(63, 19)
        Me.rdo2CCD.TabIndex = 0
        Me.rdo2CCD.Text = "2CCD"
        Me.rdo2CCD.UseVisualStyleBackColor = True
        '
        'rdo3CCD
        '
        Me.rdo3CCD.AutoSize = True
        Me.rdo3CCD.Location = New System.Drawing.Point(161, 22)
        Me.rdo3CCD.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rdo3CCD.Name = "rdo3CCD"
        Me.rdo3CCD.Size = New System.Drawing.Size(63, 19)
        Me.rdo3CCD.TabIndex = 0
        Me.rdo3CCD.Text = "3CCD"
        Me.rdo3CCD.UseVisualStyleBackColor = True
        '
        'rdo1CCD
        '
        Me.rdo1CCD.AutoSize = True
        Me.rdo1CCD.Location = New System.Drawing.Point(12, 24)
        Me.rdo1CCD.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rdo1CCD.Name = "rdo1CCD"
        Me.rdo1CCD.Size = New System.Drawing.Size(63, 19)
        Me.rdo1CCD.TabIndex = 0
        Me.rdo1CCD.Text = "1CCD"
        Me.rdo1CCD.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.chkBMMode)
        Me.GroupBox3.Controls.Add(Me.chkRotate)
        Me.GroupBox3.Controls.Add(Me.chkOverlap)
        Me.GroupBox3.Controls.Add(Me.chkCCD7)
        Me.GroupBox3.Controls.Add(Me.chkCCD9)
        Me.GroupBox3.Controls.Add(Me.chkCCD4)
        Me.GroupBox3.Controls.Add(Me.chkCCD6)
        Me.GroupBox3.Controls.Add(Me.chkCCD8)
        Me.GroupBox3.Controls.Add(Me.chkCCD3)
        Me.GroupBox3.Controls.Add(Me.chkCCD5)
        Me.GroupBox3.Controls.Add(Me.chkCCD2)
        Me.GroupBox3.Controls.Add(Me.chkCCD1)
        Me.GroupBox3.Controls.Add(Me.ckbOpMode)
        Me.GroupBox3.Location = New System.Drawing.Point(11, 184)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox3.Size = New System.Drawing.Size(249, 160)
        Me.GroupBox3.TabIndex = 65
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "View Select"
        '
        'chkBMMode
        '
        Me.chkBMMode.AutoSize = True
        Me.chkBMMode.Location = New System.Drawing.Point(144, 101)
        Me.chkBMMode.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkBMMode.Name = "chkBMMode"
        Me.chkBMMode.Size = New System.Drawing.Size(91, 19)
        Me.chkBMMode.TabIndex = 6
        Me.chkBMMode.Text = "BM_Mode"
        Me.chkBMMode.UseVisualStyleBackColor = True
        '
        'chkRotate
        '
        Me.chkRotate.AutoSize = True
        Me.chkRotate.Location = New System.Drawing.Point(9, 129)
        Me.chkRotate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkRotate.Name = "chkRotate"
        Me.chkRotate.Size = New System.Drawing.Size(118, 19)
        Me.chkRotate.TabIndex = 5
        Me.chkRotate.Text = "Rotate 180 deg."
        Me.chkRotate.UseVisualStyleBackColor = True
        '
        'chkOverlap
        '
        Me.chkOverlap.AutoSize = True
        Me.chkOverlap.Location = New System.Drawing.Point(9, 101)
        Me.chkOverlap.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkOverlap.Name = "chkOverlap"
        Me.chkOverlap.Size = New System.Drawing.Size(112, 19)
        Me.chkOverlap.TabIndex = 4
        Me.chkOverlap.Text = "Overlap Count"
        Me.chkOverlap.UseVisualStyleBackColor = True
        '
        'chkCCD7
        '
        Me.chkCCD7.AutoSize = True
        Me.chkCCD7.Location = New System.Drawing.Point(9, 72)
        Me.chkCCD7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkCCD7.Name = "chkCCD7"
        Me.chkCCD7.Size = New System.Drawing.Size(64, 19)
        Me.chkCCD7.TabIndex = 3
        Me.chkCCD7.Text = "CCD7"
        Me.chkCCD7.UseVisualStyleBackColor = True
        '
        'chkCCD9
        '
        Me.chkCCD9.AutoSize = True
        Me.chkCCD9.Location = New System.Drawing.Point(165, 72)
        Me.chkCCD9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkCCD9.Name = "chkCCD9"
        Me.chkCCD9.Size = New System.Drawing.Size(64, 19)
        Me.chkCCD9.TabIndex = 2
        Me.chkCCD9.Text = "CCD9"
        Me.chkCCD9.UseVisualStyleBackColor = True
        '
        'chkCCD4
        '
        Me.chkCCD4.AutoSize = True
        Me.chkCCD4.Location = New System.Drawing.Point(9, 46)
        Me.chkCCD4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkCCD4.Name = "chkCCD4"
        Me.chkCCD4.Size = New System.Drawing.Size(64, 19)
        Me.chkCCD4.TabIndex = 3
        Me.chkCCD4.Text = "CCD4"
        Me.chkCCD4.UseVisualStyleBackColor = True
        '
        'chkCCD6
        '
        Me.chkCCD6.AutoSize = True
        Me.chkCCD6.Location = New System.Drawing.Point(165, 48)
        Me.chkCCD6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkCCD6.Name = "chkCCD6"
        Me.chkCCD6.Size = New System.Drawing.Size(64, 19)
        Me.chkCCD6.TabIndex = 2
        Me.chkCCD6.Text = "CCD6"
        Me.chkCCD6.UseVisualStyleBackColor = True
        '
        'chkCCD8
        '
        Me.chkCCD8.AutoSize = True
        Me.chkCCD8.Location = New System.Drawing.Point(87, 74)
        Me.chkCCD8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkCCD8.Name = "chkCCD8"
        Me.chkCCD8.Size = New System.Drawing.Size(64, 19)
        Me.chkCCD8.TabIndex = 1
        Me.chkCCD8.Text = "CCD8"
        Me.chkCCD8.UseVisualStyleBackColor = True
        '
        'chkCCD3
        '
        Me.chkCCD3.AutoSize = True
        Me.chkCCD3.Location = New System.Drawing.Point(165, 22)
        Me.chkCCD3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkCCD3.Name = "chkCCD3"
        Me.chkCCD3.Size = New System.Drawing.Size(64, 19)
        Me.chkCCD3.TabIndex = 2
        Me.chkCCD3.Text = "CCD3"
        Me.chkCCD3.UseVisualStyleBackColor = True
        '
        'chkCCD5
        '
        Me.chkCCD5.AutoSize = True
        Me.chkCCD5.Location = New System.Drawing.Point(87, 48)
        Me.chkCCD5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkCCD5.Name = "chkCCD5"
        Me.chkCCD5.Size = New System.Drawing.Size(64, 19)
        Me.chkCCD5.TabIndex = 1
        Me.chkCCD5.Text = "CCD5"
        Me.chkCCD5.UseVisualStyleBackColor = True
        '
        'chkCCD2
        '
        Me.chkCCD2.AutoSize = True
        Me.chkCCD2.Location = New System.Drawing.Point(87, 22)
        Me.chkCCD2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkCCD2.Name = "chkCCD2"
        Me.chkCCD2.Size = New System.Drawing.Size(64, 19)
        Me.chkCCD2.TabIndex = 1
        Me.chkCCD2.Text = "CCD2"
        Me.chkCCD2.UseVisualStyleBackColor = True
        '
        'chkCCD1
        '
        Me.chkCCD1.AutoSize = True
        Me.chkCCD1.Location = New System.Drawing.Point(9, 24)
        Me.chkCCD1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkCCD1.Name = "chkCCD1"
        Me.chkCCD1.Size = New System.Drawing.Size(64, 19)
        Me.chkCCD1.TabIndex = 0
        Me.chkCCD1.Text = "CCD1"
        Me.chkCCD1.UseVisualStyleBackColor = True
        '
        'ckbOpMode
        '
        Me.ckbOpMode.AutoSize = True
        Me.ckbOpMode.Location = New System.Drawing.Point(149, 128)
        Me.ckbOpMode.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ckbOpMode.Name = "ckbOpMode"
        Me.ckbOpMode.Size = New System.Drawing.Size(87, 19)
        Me.ckbOpMode.TabIndex = 7
        Me.ckbOpMode.Text = "OP_Mode"
        Me.ckbOpMode.UseVisualStyleBackColor = True
        '
        'btnMuraShow
        '
        Me.btnMuraShow.Enabled = False
        Me.btnMuraShow.Location = New System.Drawing.Point(13, 24)
        Me.btnMuraShow.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnMuraShow.Name = "btnMuraShow"
        Me.btnMuraShow.Size = New System.Drawing.Size(93, 38)
        Me.btnMuraShow.TabIndex = 70
        Me.btnMuraShow.Text = "MuraShow"
        Me.btnMuraShow.UseVisualStyleBackColor = True
        '
        'txtAoiJudgerResult
        '
        Me.txtAoiJudgerResult.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtAoiJudgerResult.Font = New System.Drawing.Font("新細明體", 20.0!)
        Me.txtAoiJudgerResult.ForeColor = System.Drawing.Color.White
        Me.txtAoiJudgerResult.Location = New System.Drawing.Point(0, 0)
        Me.txtAoiJudgerResult.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtAoiJudgerResult.Multiline = True
        Me.txtAoiJudgerResult.Name = "txtAoiJudgerResult"
        Me.txtAoiJudgerResult.ReadOnly = True
        Me.txtAoiJudgerResult.Size = New System.Drawing.Size(257, 88)
        Me.txtAoiJudgerResult.TabIndex = 71
        Me.txtAoiJudgerResult.Text = "顯現不良品"
        Me.txtAoiJudgerResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'rtbJudgeResultFile
        '
        Me.rtbJudgeResultFile.Location = New System.Drawing.Point(529, 160)
        Me.rtbJudgeResultFile.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rtbJudgeResultFile.Name = "rtbJudgeResultFile"
        Me.rtbJudgeResultFile.Size = New System.Drawing.Size(519, 112)
        Me.rtbJudgeResultFile.TabIndex = 0
        Me.rtbJudgeResultFile.Text = ""
        Me.rtbJudgeResultFile.WordWrap = False
        '
        'rbDetailInfo
        '
        Me.rbDetailInfo.AutoSize = True
        Me.rbDetailInfo.Location = New System.Drawing.Point(9, 16)
        Me.rbDetailInfo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbDetailInfo.Name = "rbDetailInfo"
        Me.rbDetailInfo.Size = New System.Drawing.Size(73, 19)
        Me.rbDetailInfo.TabIndex = 73
        Me.rbDetailInfo.Text = "非宮格"
        Me.rbDetailInfo.UseVisualStyleBackColor = True
        '
        'rbMuraPartition
        '
        Me.rbMuraPartition.AutoSize = True
        Me.rbMuraPartition.Checked = True
        Me.rbMuraPartition.Location = New System.Drawing.Point(96, 16)
        Me.rbMuraPartition.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbMuraPartition.Name = "rbMuraPartition"
        Me.rbMuraPartition.Size = New System.Drawing.Size(58, 19)
        Me.rbMuraPartition.TabIndex = 74
        Me.rbMuraPartition.TabStop = True
        Me.rbMuraPartition.Text = "宮格"
        Me.rbMuraPartition.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.rbRightView)
        Me.GroupBox5.Controls.Add(Me.rbNormalView)
        Me.GroupBox5.Controls.Add(Me.rbLeftView)
        Me.GroupBox5.Location = New System.Drawing.Point(203, 231)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox5.Size = New System.Drawing.Size(263, 48)
        Me.GroupBox5.TabIndex = 75
        Me.GroupBox5.TabStop = False
        '
        'rbRightView
        '
        Me.rbRightView.AutoSize = True
        Me.rbRightView.Location = New System.Drawing.Point(176, 18)
        Me.rbRightView.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbRightView.Name = "rbRightView"
        Me.rbRightView.Size = New System.Drawing.Size(73, 19)
        Me.rbRightView.TabIndex = 2
        Me.rbRightView.Text = "右視角"
        Me.rbRightView.UseVisualStyleBackColor = True
        '
        'rbNormalView
        '
        Me.rbNormalView.AutoSize = True
        Me.rbNormalView.Checked = True
        Me.rbNormalView.Location = New System.Drawing.Point(91, 18)
        Me.rbNormalView.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbNormalView.Name = "rbNormalView"
        Me.rbNormalView.Size = New System.Drawing.Size(73, 19)
        Me.rbNormalView.TabIndex = 1
        Me.rbNormalView.TabStop = True
        Me.rbNormalView.Text = "正視角"
        Me.rbNormalView.UseVisualStyleBackColor = True
        '
        'rbLeftView
        '
        Me.rbLeftView.AutoSize = True
        Me.rbLeftView.Location = New System.Drawing.Point(8, 19)
        Me.rbLeftView.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbLeftView.Name = "rbLeftView"
        Me.rbLeftView.Size = New System.Drawing.Size(73, 19)
        Me.rbLeftView.TabIndex = 0
        Me.rbLeftView.Text = "左視角"
        Me.rbLeftView.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.rbDetailInfo)
        Me.GroupBox6.Controls.Add(Me.rbMuraPartition)
        Me.GroupBox6.Location = New System.Drawing.Point(8, 235)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox6.Size = New System.Drawing.Size(187, 44)
        Me.GroupBox6.TabIndex = 76
        Me.GroupBox6.TabStop = False
        '
        'gbSettingTool
        '
        Me.gbSettingTool.Controls.Add(Me.GroupBox1)
        Me.gbSettingTool.Controls.Add(Me.btnMuraShow)
        Me.gbSettingTool.Controls.Add(Me.GroupBox3)
        Me.gbSettingTool.Controls.Add(Me.GroupBox2)
        Me.gbSettingTool.Location = New System.Drawing.Point(1063, 32)
        Me.gbSettingTool.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbSettingTool.Name = "gbSettingTool"
        Me.gbSettingTool.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbSettingTool.Size = New System.Drawing.Size(268, 770)
        Me.gbSettingTool.TabIndex = 77
        Me.gbSettingTool.TabStop = False
        Me.gbSettingTool.Text = "Setting"
        '
        'TabControl_ShowDefect
        '
        Me.TabControl_ShowDefect.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl_ShowDefect.Controls.Add(Me.TabPage_AOI)
        Me.TabControl_ShowDefect.Controls.Add(Me.TabPage_Luminance)
        Me.TabControl_ShowDefect.Location = New System.Drawing.Point(0, 284)
        Me.TabControl_ShowDefect.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabControl_ShowDefect.Name = "TabControl_ShowDefect"
        Me.TabControl_ShowDefect.SelectedIndex = 0
        Me.TabControl_ShowDefect.Size = New System.Drawing.Size(1068, 612)
        Me.TabControl_ShowDefect.TabIndex = 29
        '
        'TabPage_AOI
        '
        Me.TabPage_AOI.BackColor = System.Drawing.SystemColors.Control
        Me.TabPage_AOI.Controls.Add(Me.grpDefectMapping)
        Me.TabPage_AOI.Location = New System.Drawing.Point(4, 28)
        Me.TabPage_AOI.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage_AOI.Name = "TabPage_AOI"
        Me.TabPage_AOI.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage_AOI.Size = New System.Drawing.Size(1060, 580)
        Me.TabPage_AOI.TabIndex = 0
        Me.TabPage_AOI.Text = "AOI Result"
        '
        'grpDefectMapping
        '
        Me.grpDefectMapping.BackColor = System.Drawing.SystemColors.Control
        Me.grpDefectMapping.Controls.Add(Me.labPanelH)
        Me.grpDefectMapping.Controls.Add(Me.labPanelW)
        Me.grpDefectMapping.Controls.Add(Me.labPanelMinH)
        Me.grpDefectMapping.Controls.Add(Me.labPanelMinW)
        Me.grpDefectMapping.Controls.Add(Me.picView)
        Me.grpDefectMapping.Location = New System.Drawing.Point(1, 4)
        Me.grpDefectMapping.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.grpDefectMapping.Name = "grpDefectMapping"
        Me.grpDefectMapping.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.grpDefectMapping.Size = New System.Drawing.Size(1052, 575)
        Me.grpDefectMapping.TabIndex = 73
        Me.grpDefectMapping.TabStop = False
        '
        'labPanelH
        '
        Me.labPanelH.AutoSize = True
        Me.labPanelH.Location = New System.Drawing.Point(3, 554)
        Me.labPanelH.Name = "labPanelH"
        Me.labPanelH.Size = New System.Drawing.Size(35, 15)
        Me.labPanelH.TabIndex = 9
        Me.labPanelH.Text = "0000"
        Me.labPanelH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'labPanelW
        '
        Me.labPanelW.AutoSize = True
        Me.labPanelW.Location = New System.Drawing.Point(1005, 12)
        Me.labPanelW.Name = "labPanelW"
        Me.labPanelW.Size = New System.Drawing.Size(35, 15)
        Me.labPanelW.TabIndex = 12
        Me.labPanelW.Text = "0000"
        Me.labPanelW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'labPanelMinH
        '
        Me.labPanelMinH.AutoSize = True
        Me.labPanelMinH.Location = New System.Drawing.Point(5, 26)
        Me.labPanelMinH.Name = "labPanelMinH"
        Me.labPanelMinH.Size = New System.Drawing.Size(14, 15)
        Me.labPanelMinH.TabIndex = 10
        Me.labPanelMinH.Text = "0"
        Me.labPanelMinH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'labPanelMinW
        '
        Me.labPanelMinW.AutoSize = True
        Me.labPanelMinW.Location = New System.Drawing.Point(19, 10)
        Me.labPanelMinW.Name = "labPanelMinW"
        Me.labPanelMinW.Size = New System.Drawing.Size(14, 15)
        Me.labPanelMinW.TabIndex = 11
        Me.labPanelMinW.Text = "0"
        Me.labPanelMinW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picView
        '
        Me.picView.BackColor = System.Drawing.SystemColors.ControlDark
        Me.picView.Location = New System.Drawing.Point(21, 31)
        Me.picView.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.picView.Name = "picView"
        Me.picView.Size = New System.Drawing.Size(1019, 538)
        Me.picView.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picView.TabIndex = 28
        Me.picView.TabStop = False
        '
        'TabPage_Luminance
        '
        Me.TabPage_Luminance.BackColor = System.Drawing.SystemColors.Control
        Me.TabPage_Luminance.Controls.Add(Me.lb_MeasureParam)
        Me.TabPage_Luminance.Controls.Add(Me.dgv_MeasureResult)
        Me.TabPage_Luminance.Controls.Add(Me.Label2)
        Me.TabPage_Luminance.Controls.Add(Me.cbo_MeasurePatternName)
        Me.TabPage_Luminance.Location = New System.Drawing.Point(4, 28)
        Me.TabPage_Luminance.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage_Luminance.Name = "TabPage_Luminance"
        Me.TabPage_Luminance.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage_Luminance.Size = New System.Drawing.Size(1060, 580)
        Me.TabPage_Luminance.TabIndex = 1
        Me.TabPage_Luminance.Text = "Measure Result"
        '
        'lb_MeasureParam
        '
        Me.lb_MeasureParam.AutoSize = True
        Me.lb_MeasureParam.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.lb_MeasureParam.Location = New System.Drawing.Point(744, 45)
        Me.lb_MeasureParam.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lb_MeasureParam.Name = "lb_MeasureParam"
        Me.lb_MeasureParam.Size = New System.Drawing.Size(0, 20)
        Me.lb_MeasureParam.TabIndex = 9
        '
        'dgv_MeasureResult
        '
        Me.dgv_MeasureResult.AllowUserToAddRows = False
        Me.dgv_MeasureResult.AllowUserToDeleteRows = False
        Me.dgv_MeasureResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_MeasureResult.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5})
        Me.dgv_MeasureResult.Enabled = False
        Me.dgv_MeasureResult.Location = New System.Drawing.Point(3, 41)
        Me.dgv_MeasureResult.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgv_MeasureResult.Name = "dgv_MeasureResult"
        Me.dgv_MeasureResult.RowHeadersWidth = 51
        Me.dgv_MeasureResult.RowTemplate.Height = 24
        Me.dgv_MeasureResult.Size = New System.Drawing.Size(724, 199)
        Me.dgv_MeasureResult.TabIndex = 2
        '
        'Column1
        '
        Me.Column1.HeaderText = ""
        Me.Column1.MinimumWidth = 6
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 125
        '
        'Column2
        '
        Me.Column2.HeaderText = ""
        Me.Column2.MinimumWidth = 6
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 125
        '
        'Column3
        '
        Me.Column3.HeaderText = ""
        Me.Column3.MinimumWidth = 6
        Me.Column3.Name = "Column3"
        Me.Column3.Width = 125
        '
        'Column4
        '
        Me.Column4.HeaderText = ""
        Me.Column4.MinimumWidth = 6
        Me.Column4.Name = "Column4"
        Me.Column4.Width = 125
        '
        'Column5
        '
        Me.Column5.HeaderText = ""
        Me.Column5.MinimumWidth = 6
        Me.Column5.Name = "Column5"
        Me.Column5.Width = 125
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 14)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Pattern："
        '
        'cbo_MeasurePatternName
        '
        Me.cbo_MeasurePatternName.FormattingEnabled = True
        Me.cbo_MeasurePatternName.Location = New System.Drawing.Point(81, 10)
        Me.cbo_MeasurePatternName.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbo_MeasurePatternName.Name = "cbo_MeasurePatternName"
        Me.cbo_MeasurePatternName.Size = New System.Drawing.Size(160, 23)
        Me.cbo_MeasurePatternName.TabIndex = 0
        '
        'SplitContainer_OKNGShow
        '
        Me.SplitContainer_OKNGShow.Location = New System.Drawing.Point(8, 148)
        Me.SplitContainer_OKNGShow.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.SplitContainer_OKNGShow.Name = "SplitContainer_OKNGShow"
        '
        'SplitContainer_OKNGShow.Panel1
        '
        Me.SplitContainer_OKNGShow.Panel1.Controls.Add(Me.txtAoiJudgerResult)
        '
        'SplitContainer_OKNGShow.Panel2
        '
        Me.SplitContainer_OKNGShow.Panel2.Controls.Add(Me.txtLuminanceResult)
        Me.SplitContainer_OKNGShow.Size = New System.Drawing.Size(516, 88)
        Me.SplitContainer_OKNGShow.SplitterDistance = 257
        Me.SplitContainer_OKNGShow.SplitterWidth = 5
        Me.SplitContainer_OKNGShow.TabIndex = 13
        '
        'txtLuminanceResult
        '
        Me.txtLuminanceResult.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtLuminanceResult.Font = New System.Drawing.Font("新細明體", 20.0!)
        Me.txtLuminanceResult.ForeColor = System.Drawing.Color.White
        Me.txtLuminanceResult.Location = New System.Drawing.Point(0, 0)
        Me.txtLuminanceResult.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtLuminanceResult.Multiline = True
        Me.txtLuminanceResult.Name = "txtLuminanceResult"
        Me.txtLuminanceResult.ReadOnly = True
        Me.txtLuminanceResult.Size = New System.Drawing.Size(254, 88)
        Me.txtLuminanceResult.TabIndex = 72
        Me.txtLuminanceResult.Text = "顯現不良品"
        Me.txtLuminanceResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'SplitContainer_OKNGTitle
        '
        Me.SplitContainer_OKNGTitle.Location = New System.Drawing.Point(8, 109)
        Me.SplitContainer_OKNGTitle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.SplitContainer_OKNGTitle.Name = "SplitContainer_OKNGTitle"
        '
        'SplitContainer_OKNGTitle.Panel1
        '
        Me.SplitContainer_OKNGTitle.Panel1.Controls.Add(Me.Label4)
        '
        'SplitContainer_OKNGTitle.Panel2
        '
        Me.SplitContainer_OKNGTitle.Panel2.Controls.Add(Me.Label5)
        Me.SplitContainer_OKNGTitle.Size = New System.Drawing.Size(516, 35)
        Me.SplitContainer_OKNGTitle.SplitterDistance = 257
        Me.SplitContainer_OKNGTitle.SplitterWidth = 5
        Me.SplitContainer_OKNGTitle.TabIndex = 14
        '
        'Label4
        '
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.Location = New System.Drawing.Point(0, 0)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(257, 35)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "AOI"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label5.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label5.Location = New System.Drawing.Point(0, 0)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(254, 35)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "LUMINANCE"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtAoiJudgerAGSResult
        '
        Me.txtAoiJudgerAGSResult.Font = New System.Drawing.Font("新細明體", 20.0!)
        Me.txtAoiJudgerAGSResult.ForeColor = System.Drawing.Color.White
        Me.txtAoiJudgerAGSResult.Location = New System.Drawing.Point(393, 148)
        Me.txtAoiJudgerAGSResult.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtAoiJudgerAGSResult.Multiline = True
        Me.txtAoiJudgerAGSResult.Name = "txtAoiJudgerAGSResult"
        Me.txtAoiJudgerAGSResult.ReadOnly = True
        Me.txtAoiJudgerAGSResult.Size = New System.Drawing.Size(129, 69)
        Me.txtAoiJudgerAGSResult.TabIndex = 78
        Me.txtAoiJudgerAGSResult.Text = "顯現不良品"
        Me.txtAoiJudgerAGSResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtAoiJudgerAGSResult.Visible = False
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.Controls.Add(Me.labDfImgMsg)
        Me.Panel1.Controls.Add(Me.picDfImg)
        Me.Panel1.Location = New System.Drawing.Point(8, 19)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(229, 146)
        Me.Panel1.TabIndex = 67
        '
        'labDfImgMsg
        '
        Me.labDfImgMsg.AutoSize = True
        Me.labDfImgMsg.BackColor = System.Drawing.Color.Red
        Me.labDfImgMsg.Font = New System.Drawing.Font("新細明體", 10.0!)
        Me.labDfImgMsg.Location = New System.Drawing.Point(8, 75)
        Me.labDfImgMsg.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.labDfImgMsg.Name = "labDfImgMsg"
        Me.labDfImgMsg.Size = New System.Drawing.Size(183, 17)
        Me.labDfImgMsg.TabIndex = 1
        Me.labDfImgMsg.Text = "檔案不存在或路徑錯誤!"
        Me.labDfImgMsg.Visible = False
        '
        'picDfImg
        '
        Me.picDfImg.Location = New System.Drawing.Point(4, 4)
        Me.picDfImg.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.picDfImg.Name = "picDfImg"
        Me.picDfImg.Size = New System.Drawing.Size(160, 90)
        Me.picDfImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDfImg.TabIndex = 0
        Me.picDfImg.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Panel1)
        Me.GroupBox4.Location = New System.Drawing.Point(1355, 191)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox4.Size = New System.Drawing.Size(245, 172)
        Me.GroupBox4.TabIndex = 68
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Show Defect Image"
        Me.GroupBox4.Visible = False
        '
        'lb_MeasureAve
        '
        Me.lb_MeasureAve.AutoSize = True
        Me.lb_MeasureAve.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.lb_MeasureAve.Location = New System.Drawing.Point(532, 145)
        Me.lb_MeasureAve.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lb_MeasureAve.Name = "lb_MeasureAve"
        Me.lb_MeasureAve.Size = New System.Drawing.Size(86, 20)
        Me.lb_MeasureAve.TabIndex = 5
        Me.lb_MeasureAve.Text = "Average : "
        Me.lb_MeasureAve.Visible = False
        '
        'lb_Measure5U
        '
        Me.lb_Measure5U.AutoSize = True
        Me.lb_Measure5U.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.lb_Measure5U.Location = New System.Drawing.Point(709, 145)
        Me.lb_Measure5U.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lb_Measure5U.Name = "lb_Measure5U"
        Me.lb_Measure5U.Size = New System.Drawing.Size(121, 20)
        Me.lb_Measure5U.TabIndex = 6
        Me.lb_Measure5U.Text = "Uniformity 5 : "
        Me.lb_Measure5U.Visible = False
        '
        'lb_Measure13U
        '
        Me.lb_Measure13U.AutoSize = True
        Me.lb_Measure13U.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.lb_Measure13U.Location = New System.Drawing.Point(920, 145)
        Me.lb_Measure13U.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lb_Measure13U.Name = "lb_Measure13U"
        Me.lb_Measure13U.Size = New System.Drawing.Size(130, 20)
        Me.lb_Measure13U.TabIndex = 7
        Me.lb_Measure13U.Text = "Uniformity 13 : "
        Me.lb_Measure13U.Visible = False
        '
        'txt_MeasureAvg
        '
        Me.txt_MeasureAvg.BackColor = System.Drawing.SystemColors.Window
        Me.txt_MeasureAvg.Location = New System.Drawing.Point(632, 146)
        Me.txt_MeasureAvg.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_MeasureAvg.Name = "txt_MeasureAvg"
        Me.txt_MeasureAvg.ReadOnly = True
        Me.txt_MeasureAvg.Size = New System.Drawing.Size(72, 25)
        Me.txt_MeasureAvg.TabIndex = 10
        Me.txt_MeasureAvg.Visible = False
        '
        'txt_Measure5U
        '
        Me.txt_Measure5U.BackColor = System.Drawing.SystemColors.Window
        Me.txt_Measure5U.Location = New System.Drawing.Point(844, 146)
        Me.txt_Measure5U.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_Measure5U.Name = "txt_Measure5U"
        Me.txt_Measure5U.ReadOnly = True
        Me.txt_Measure5U.Size = New System.Drawing.Size(72, 25)
        Me.txt_Measure5U.TabIndex = 79
        Me.txt_Measure5U.Visible = False
        '
        'txt_Measure13U
        '
        Me.txt_Measure13U.BackColor = System.Drawing.SystemColors.Window
        Me.txt_Measure13U.Location = New System.Drawing.Point(1067, 146)
        Me.txt_Measure13U.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_Measure13U.Name = "txt_Measure13U"
        Me.txt_Measure13U.ReadOnly = True
        Me.txt_Measure13U.Size = New System.Drawing.Size(72, 25)
        Me.txt_Measure13U.TabIndex = 80
        Me.txt_Measure13U.Visible = False
        '
        'FrmMain
        '
        Me.AllowDrop = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1359, 896)
        Me.Controls.Add(Me.txt_Measure13U)
        Me.Controls.Add(Me.txt_Measure5U)
        Me.Controls.Add(Me.txt_MeasureAvg)
        Me.Controls.Add(Me.lb_Measure13U)
        Me.Controls.Add(Me.SplitContainer_OKNGTitle)
        Me.Controls.Add(Me.SplitContainer_OKNGShow)
        Me.Controls.Add(Me.TabControl_ShowDefect)
        Me.Controls.Add(Me.txtAoiJudgerAGSResult)
        Me.Controls.Add(Me.gbSettingTool)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.lb_MeasureAve)
        Me.Controls.Add(Me.lb_Measure5U)
        Me.Controls.Add(Me.rtbJudgeResultFile)
        Me.Controls.Add(Me.teeView)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.grpJudgeInfo)
        Me.Controls.Add(Me.mnuMenu)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnuMenu
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "FrmMain"
        Me.Text = "View JudgeResult"
        Me.mnuMenu.ResumeLayout(False)
        Me.mnuMenu.PerformLayout()
        Me.grpJudgeInfo.ResumeLayout(False)
        Me.grpJudgeInfo.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.gbSettingTool.ResumeLayout(False)
        Me.TabControl_ShowDefect.ResumeLayout(False)
        Me.TabPage_AOI.ResumeLayout(False)
        Me.grpDefectMapping.ResumeLayout(False)
        Me.grpDefectMapping.PerformLayout()
        CType(Me.picView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Luminance.ResumeLayout(False)
        Me.TabPage_Luminance.PerformLayout()
        CType(Me.dgv_MeasureResult, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer_OKNGShow.Panel1.ResumeLayout(False)
        Me.SplitContainer_OKNGShow.Panel1.PerformLayout()
        Me.SplitContainer_OKNGShow.Panel2.ResumeLayout(False)
        Me.SplitContainer_OKNGShow.Panel2.PerformLayout()
        CType(Me.SplitContainer_OKNGShow, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer_OKNGShow.ResumeLayout(False)
        Me.SplitContainer_OKNGTitle.Panel1.ResumeLayout(False)
        Me.SplitContainer_OKNGTitle.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer_OKNGTitle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer_OKNGTitle.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.picDfImg, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnuMenu As System.Windows.Forms.MenuStrip
    Friend WithEvents tsmFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmOpen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents labDP1 As System.Windows.Forms.Label
    Friend WithEvents labBP1 As System.Windows.Forms.Label
    Friend WithEvents txtBP1 As System.Windows.Forms.Label
    Friend WithEvents txtDP1 As System.Windows.Forms.Label
    Friend WithEvents labVL As System.Windows.Forms.Label
    Friend WithEvents txtVL As System.Windows.Forms.Label
    Friend WithEvents txtHL As System.Windows.Forms.Label
    Friend WithEvents labHL As System.Windows.Forms.Label
    Friend WithEvents txtHOL As System.Windows.Forms.Label
    Friend WithEvents labHOL As System.Windows.Forms.Label
    Friend WithEvents txtVOL As System.Windows.Forms.Label
    Friend WithEvents labVOL As System.Windows.Forms.Label
    Friend WithEvents txtDP2 As System.Windows.Forms.Label
    Friend WithEvents txtBP2 As System.Windows.Forms.Label
    Friend WithEvents labDP2 As System.Windows.Forms.Label
    Friend WithEvents labBP2 As System.Windows.Forms.Label
    Friend WithEvents txtBPDP2 As System.Windows.Forms.Label
    Friend WithEvents labBPDP2 As System.Windows.Forms.Label
    Friend WithEvents txtBPDP3 As System.Windows.Forms.Label
    Friend WithEvents labBPDP3 As System.Windows.Forms.Label
    Friend WithEvents txtDP3 As System.Windows.Forms.Label
    Friend WithEvents txtBP3 As System.Windows.Forms.Label
    Friend WithEvents labDP3 As System.Windows.Forms.Label
    Friend WithEvents labBP3 As System.Windows.Forms.Label
    Friend WithEvents txtBPDPx As System.Windows.Forms.Label
    Friend WithEvents labBPDPx As System.Windows.Forms.Label
    Friend WithEvents txtDPx As System.Windows.Forms.Label
    Friend WithEvents txtBPx As System.Windows.Forms.Label
    Friend WithEvents labDPx As System.Windows.Forms.Label
    Friend WithEvents labBPx As System.Windows.Forms.Label
    Friend WithEvents txtDPn As System.Windows.Forms.Label
    Friend WithEvents labDPn As System.Windows.Forms.Label
    Friend WithEvents txtBPn As System.Windows.Forms.Label
    Friend WithEvents labBPn As System.Windows.Forms.Label
    Friend WithEvents txtBPDPn As System.Windows.Forms.Label
    Friend WithEvents labBPDPn As System.Windows.Forms.Label
    Friend WithEvents txtXL As System.Windows.Forms.Label
    Friend WithEvents labXL As System.Windows.Forms.Label
    Friend WithEvents grpJudgeInfo As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents chkCCD4 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCCD3 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCCD2 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCCD1 As System.Windows.Forms.CheckBox
    Friend WithEvents tsmSetting As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmPanelSize As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmDefectColor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkOverlap As System.Windows.Forms.CheckBox
    Friend WithEvents txtMURA As System.Windows.Forms.Label
    Friend WithEvents labMURA As System.Windows.Forms.Label
    Friend WithEvents txtCP As System.Windows.Forms.Label
    Friend WithEvents labCP As System.Windows.Forms.Label
    Friend WithEvents txtSBP As System.Windows.Forms.Label
    Friend WithEvents labSBP As System.Windows.Forms.Label
    Friend WithEvents chkRotate As System.Windows.Forms.CheckBox
    Friend WithEvents txtOmitBP As System.Windows.Forms.Label
    Friend WithEvents labOmitBP As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdo9CCD As System.Windows.Forms.RadioButton
    Friend WithEvents rdo4CCD As System.Windows.Forms.RadioButton
    Friend WithEvents rdo3CCD As System.Windows.Forms.RadioButton
    Friend WithEvents rdo1CCD As System.Windows.Forms.RadioButton
    Friend WithEvents chkCCD7 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCCD9 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCCD6 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCCD8 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCCD5 As System.Windows.Forms.CheckBox
    Friend WithEvents rdo2CCD As System.Windows.Forms.RadioButton
    Friend WithEvents txtSBB As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtFG As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents chkBMMode As System.Windows.Forms.CheckBox
    Friend WithEvents txtSGBB As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtLBB As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtMBB As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ckbOpMode As System.Windows.Forms.CheckBox
    Friend WithEvents teeView As System.Windows.Forms.TreeView
    Friend WithEvents OpenNotePadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnMuraShow As System.Windows.Forms.Button
    Friend WithEvents txtAoiJudgerResult As System.Windows.Forms.TextBox
    Friend WithEvents txtBLDP As System.Windows.Forms.Label
    Friend WithEvents txtGSBP As System.Windows.Forms.Label
    Friend WithEvents labBLDP As System.Windows.Forms.Label
    Friend WithEvents labGSBP As System.Windows.Forms.Label
    Friend WithEvents rtbJudgeResultFile As System.Windows.Forms.RichTextBox
    Friend WithEvents txtPanelID As System.Windows.Forms.TextBox
    Friend WithEvents txtMainDefect As System.Windows.Forms.TextBox
    Friend WithEvents txtAgsRank As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtCstRank As System.Windows.Forms.TextBox
    Friend WithEvents Label_AGSRank As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents rbDetailInfo As System.Windows.Forms.RadioButton
    Friend WithEvents rbMuraPartition As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents rbNormalView As System.Windows.Forms.RadioButton
    Friend WithEvents rbLeftView As System.Windows.Forms.RadioButton
    Friend WithEvents rbRightView As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents gbSettingTool As GroupBox
    Friend WithEvents TabControl_ShowDefect As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_AOI As System.Windows.Forms.TabPage
    Friend WithEvents grpDefectMapping As System.Windows.Forms.GroupBox
    Friend WithEvents labPanelH As System.Windows.Forms.Label
    Friend WithEvents labPanelW As System.Windows.Forms.Label
    Friend WithEvents labPanelMinH As System.Windows.Forms.Label
    Friend WithEvents labPanelMinW As System.Windows.Forms.Label
    Friend WithEvents picView As System.Windows.Forms.PictureBox
    Friend WithEvents TabPage_Luminance As System.Windows.Forms.TabPage
    Friend WithEvents dgv_MeasureResult As System.Windows.Forms.DataGridView
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cbo_MeasurePatternName As System.Windows.Forms.ComboBox
    Friend WithEvents lb_MeasureParam As System.Windows.Forms.Label
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SplitContainer_OKNGShow As System.Windows.Forms.SplitContainer
    Friend WithEvents txtLuminanceResult As System.Windows.Forms.TextBox
    Friend WithEvents SplitContainer_OKNGTitle As System.Windows.Forms.SplitContainer
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tsmDefectView As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txtAoiJudgerAGSResult As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents labDfImgMsg As System.Windows.Forms.Label
    Friend WithEvents picDfImg As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents lb_MeasureAve As System.Windows.Forms.Label
    Friend WithEvents lb_Measure5U As System.Windows.Forms.Label
    Friend WithEvents lb_Measure13U As System.Windows.Forms.Label
    Friend WithEvents txt_MeasureAvg As System.Windows.Forms.TextBox
    Friend WithEvents txt_Measure5U As System.Windows.Forms.TextBox
    Friend WithEvents txt_Measure13U As System.Windows.Forms.TextBox
End Class
